// assets/js/student_validation.js

document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('signup-form');
    
    // Validate name (only letters, not empty)
    const validateName = (name) => {
        if (!name || name.trim() === '') {
            return { isValid: false, message: 'Name cannot be empty' };
        }
        // Check if contains only letters (and spaces)
        const nameRegex = /^[A-Za-z\s]+$/;
        if (!nameRegex.test(name)) {
            return { isValid: false, message: 'Name must contain only letters' };
        }
        return { isValid: true, message: '' };
    };

    // Validate email
    const validateEmail = (email) => {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    };

    // Validate password (min 8 chars, uppercase, lowercase, number, special char)
    const validatePassword = (password) => {
        const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*(),.?":{}|<>])[A-Za-z\d!@#$%^&*(),.?":{}|<>]{8,}$/;
        return passwordRegex.test(password);
    };

    // Validate student ID (not empty)
    const validateStudentId = (studentId) => {
        return studentId && studentId.trim() !== '';
    };

    // Validate institution (not empty)
    const validateInstitution = (institution) => {
        return institution && institution.trim() !== '';
    };

    const setError = (element, message) => {
        const formControl = element.parentElement;
        const small = formControl.querySelector('small');
        formControl.className = 'form-control error';
        small.innerText = message;
        small.style.display = 'block';
    };

    const setSuccess = (element) => {
        const formControl = element.parentElement;
        formControl.className = 'form-control success';
        const small = formControl.querySelector('small');
        small.style.display = 'none';
    };

    form.addEventListener('submit', function(e) {
        e.preventDefault();

        const firstname = document.getElementById('firstname');
        const lastname = document.getElementById('lastname');
        const email = document.getElementById('email');
        const studentId = document.getElementById('student_id');
        const institution = document.getElementById('institution');
        const program = document.getElementById('program');
        const year = document.getElementById('year');
        const password = document.getElementById('password');
        const confirmPassword = document.getElementById('confirm_password');
        const terms = document.getElementById('terms');

        let isValid = true;

        // Firstname validation
        const firstNameResult = validateName(firstname.value.trim());
        if (!firstNameResult.isValid) {
            setError(firstname, firstNameResult.message);
            isValid = false;
        } else {
            setSuccess(firstname);
        }

        // Lastname validation
        const lastNameResult = validateName(lastname.value.trim());
        if (!lastNameResult.isValid) {
            setError(lastname, lastNameResult.message);
            isValid = false;
        } else {
            setSuccess(lastname);
        }

        // Email validation
        if (!validateEmail(email.value.trim())) {
            setError(email, 'Please enter a valid email address');
            isValid = false;
        } else {
            setSuccess(email);
        }

        // Student ID validation
        if (!validateStudentId(studentId.value)) {
            setError(studentId, 'Student ID is required');
            isValid = false;
        } else {
            setSuccess(studentId);
        }

        // Institution validation
        if (!validateInstitution(institution.value)) {
            setError(institution, 'Institution name is required');
            isValid = false;
        } else {
            setSuccess(institution);
        }

        // Program validation
        if (!program.value) {
            setError(program, 'Please select your program');
            isValid = false;
        } else {
            setSuccess(program);
        }

        // Year validation
        if (!year.value) {
            setError(year, 'Please select your year');
            isValid = false;
        } else {
            setSuccess(year);
        }

        // Password validation
        if (!validatePassword(password.value)) {
            setError(password, 'Password must be at least 8 characters and contain uppercase, lowercase, number and special character');
            isValid = false;
        } else {
            setSuccess(password);
        }

        // Confirm password validation
        if (confirmPassword.value !== password.value) {
            setError(confirmPassword, 'Passwords do not match');
            isValid = false;
        } else if (confirmPassword.value === '') {
            setError(confirmPassword, 'Please confirm your password');
            isValid = false;
        } else {
            setSuccess(confirmPassword);
        }

        // Terms validation
        const termsParent = terms.closest('.form-control');
        if (!terms.checked) {
            termsParent.classList.add('error');
            const small = termsParent.querySelector('small');
            if (small) {
                small.innerText = 'Please accept the terms and conditions';
                small.style.display = 'block';
            }
            isValid = false;
        } else {
            termsParent.classList.remove('error');
            const small = termsParent.querySelector('small');
            if (small) {
                small.style.display = 'none';
            }
        }

        // // If all validations pass, submit the form
        // if (isValid) {
        //     form.submit();
        // }


        if (isValid) {
            // Disable the submit button to prevent double submission
            document.querySelector('.auth-btn').disabled = true;
            
            // Remove validation classes from checkbox
            const termsParent = terms.closest('.form-control');
            termsParent.className = 'form-control checkbox';
            
            // Small delay before submitting (optional)
            setTimeout(() => {
                form.submit();
            }, 100);
        }




    });

    // Real-time validation as user types
    form.querySelectorAll('input, select').forEach(input => {
        input.addEventListener('input', function() {
            if (this.value.trim() !== '') {
                if (this.id === 'firstname' || this.id === 'lastname') {
                    const nameResult = validateName(this.value.trim());
                    if (!nameResult.isValid) {
                        setError(this, nameResult.message);
                    } else {
                        setSuccess(this);
                    }
                }
            }
        });
    });
});