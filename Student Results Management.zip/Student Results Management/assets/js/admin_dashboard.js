// assets/js/admin_dashboard.js

document.addEventListener('DOMContentLoaded', function() {
    // Sidebar Toggle
    const toggleBtn = document.querySelector('.toggle-sidebar');
    const sidebar = document.querySelector('.sidebar');
    const mainContent = document.querySelector('.main-content');

    if (toggleBtn) {
        toggleBtn.addEventListener('click', function() {
            sidebar.classList.toggle('active');
            mainContent.classList.toggle('full-width');
        });
    }

    // Avatar Upload Handling
    const avatar = document.querySelector('.user-info img');
    const uploadInput = document.createElement('input');
    uploadInput.type = 'file';
    uploadInput.accept = 'image/*';
    uploadInput.style.display = 'none';
    document.body.appendChild(uploadInput);

    if (avatar) {
        avatar.addEventListener('click', function() {
            uploadInput.click();
        });

        avatar.style.cursor = 'pointer';
        avatar.title = 'Click to change avatar';
    }

    uploadInput.addEventListener('change', function(e) {
        const file = e.target.files[0];
        if (file) {
            if (file.size > 5 * 1024 * 1024) { // 5MB limit
                alert('File size should not exceed 5MB');
                return;
            }

            const formData = new FormData();
            formData.append('avatar', file);

            // Show loading state
            avatar.style.opacity = '0.5';

            fetch('../../actions/update_avatar.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Update avatar with new image
                    avatar.src = data.avatar_url + '?v=' + new Date().getTime(); // Prevent caching
                    avatar.style.opacity = '1';
                } else {
                    alert(data.message || 'Error updating avatar');
                    avatar.style.opacity = '1';
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Error updating avatar');
                avatar.style.opacity = '1';
            });
        }
    });

    // Active Link Highlighting
    const currentPath = window.location.pathname;
    const navLinks = document.querySelectorAll('.nav-links a');
    
    navLinks.forEach(link => {
        if (currentPath.includes(link.getAttribute('href'))) {
            link.parentElement.classList.add('active');
        }
    });

    // Stats Animation
    const stats = document.querySelectorAll('.stat-info p');
    stats.forEach(stat => {
        const finalValue = parseInt(stat.textContent);
        animateValue(stat, 0, finalValue, 1000);
    });
});

// Function to animate numbers
function animateValue(element, start, end, duration) {
    let startTimestamp = null;
    const step = (timestamp) => {
        if (!startTimestamp) startTimestamp = timestamp;
        const progress = Math.min((timestamp - startTimestamp) / duration, 1);
        element.textContent = Math.floor(progress * (end - start) + start);
        if (progress < 1) {
            window.requestAnimationFrame(step);
        }
    };
    window.requestAnimationFrame(step);
}