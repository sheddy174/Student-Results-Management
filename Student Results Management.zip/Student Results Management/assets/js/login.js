// assets/js/login_validation.js

document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('login-form');
    
    // Validate email
    const validateEmail = (email) => {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    };

    const setError = (element, message) => {
        const formControl = element.parentElement;
        const small = formControl.querySelector('small');
        formControl.className = 'form-control error';
        small.innerText = message;
        small.style.display = 'block';
    };

    const setSuccess = (element) => {
        const formControl = element.parentElement;
        formControl.className = 'form-control success';
        const small = formControl.querySelector('small');
        small.style.display = 'none';
    };

    form.addEventListener('submit', function(e) {
        e.preventDefault();

        const email = document.getElementById('email');
        const password = document.getElementById('password');

        let isValid = true;

        // Email validation
        if (!email.value.trim()) {
            setError(email, 'Email cannot be empty');
            isValid = false;
        } else if (!validateEmail(email.value.trim())) {
            setError(email, 'Please enter a valid email address');
            isValid = false;
        } else {
            setSuccess(email);
        }

        // Password validation
        if (!password.value.trim()) {
            setError(password, 'Password cannot be empty');
            isValid = false;
        } else {
            setSuccess(password);
        }

        // If all validations pass, submit the form
        if (isValid) {
            form.submit();
        }
    });

    // Real-time validation as user types
    form.querySelectorAll('input').forEach(input => {
        input.addEventListener('input', function() {
            if (this.value.trim() !== '') {
                if (this.id === 'email') {
                    if (!validateEmail(this.value.trim())) {
                        setError(this, 'Please enter a valid email address');
                    } else {
                        setSuccess(this);
                    }
                } else {
                    setSuccess(this);
                }
            }
        });
    });
});