
document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('signup-form');
    const firstname = document.getElementById('firstname');
    const lastname = document.getElementById('lastname');
    const email = document.getElementById('email');
    const password = document.getElementById('password');
    const confirmPassword = document.getElementById('confirm-password');
    const terms = document.getElementById('terms');

    form.addEventListener('submit', function (e) {
        e.preventDefault();
        if (validateInputs()) {
            alert('Form submitted successfully!');
            // Here you would typically send the form data to a server
        }
    });

    const inputs = [firstname, lastname, email, password, confirmPassword];
    inputs.forEach(input => {
        input.addEventListener('input', function () {
            validateInput(input);
        });
    });

    function validateInputs() {
        let isValid = true;
        inputs.forEach(input => {
            if (!validateInput(input)) {
                isValid = false;
            }
        });
        if (!terms.checked) {
            alert('Please accept the terms and conditions');
            isValid = false;
        }
        return isValid;
    }

    function validateInput(input) {
        const value = input.value.trim();

        switch (input.id) {
            case 'firstname':
            case 'lastname':
                return value === '' ? setErrorFor(input, `${input.id.charAt(0).toUpperCase() + input.id.slice(1)} cannot be blank`) :
                    !isValidName(value) ? setErrorFor(input, `${input.id.charAt(0).toUpperCase() + input.id.slice(1)} should only contain alphabets`) :
                        setSuccessFor(input);
            case 'email':
                return value === '' ? setErrorFor(input, 'Email cannot be blank') :
                    !isValidEmail(value) ? setErrorFor(input, 'Not a valid email') :
                        setSuccessFor(input);
            case 'password':
                return value === '' ? setErrorFor(input, 'Password cannot be blank') :
                    !isValidPassword(value) ? setErrorFor(input, 'Password must be at least 8 characters long, contain an uppercase letter, 3 digits, and a special character') :
                        setSuccessFor(input);
            case 'confirm-password':
                return value === '' ? setErrorFor(input, 'Please confirm your password') :
                    value !== password.value ? setErrorFor(input, 'Passwords do not match') :
                        setSuccessFor(input);
        }
    }



    // If all validations pass
    if (isValid) {
        const submitButton = this.querySelector('button[type="submit"]');
        submitButton.classList.add('loading');
        submitButton.disabled = true;

        form.submit();
    }





    function setErrorFor(input, message) {
        const formControl = input.parentElement;
        const small = formControl.querySelector('small');
        formControl.className = 'form-control error';
        small.innerText = message;
        return false;
    }

    function setSuccessFor(input) {
        const formControl = input.parentElement;
        formControl.className = 'form-control success';
        return true;
    }

    function isValidName(name) {
        return /^[A-Za-z]+$/.test(name);
    }

    function isValidEmail(email) {
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    }

    function isValidPassword(password) {
        // At least 8 characters long, contains uppercase, 3 digits, and a special character
        return /^(?=.*[A-Z])(?=.*\d.*\d.*\d)(?=.*[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>/?]).{8,}$/.test(password);
    }
});


