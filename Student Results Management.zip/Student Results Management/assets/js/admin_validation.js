// assets/js/admin_validation.js

document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('signup-form');

    // Validate name (only letters, not empty)
    const validateName = (name) => {
        if (!name || name.trim() === '') {
            return { isValid: false, message: 'Name cannot be empty' };
        }
        // Check if contains only letters (and spaces)
        const nameRegex = /^[A-Za-z\s]+$/;
        if (!nameRegex.test(name)) {
            return { isValid: false, message: 'Name must contain only letters' };
        }
        return { isValid: true, message: '' };
    };

    // Validate email
    const validateEmail = (email) => {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    };

    // Validate password (min 8 chars, uppercase, lowercase, number, special char)
    const validatePassword = (password) => {
        const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*(),.?":{}|<>])[A-Za-z\d!@#$%^&*(),.?":{}|<>]{8,}$/;
        return passwordRegex.test(password);
    };

    const setError = (element, message) => {
        const formControl = element.parentElement;
        const small = formControl.querySelector('small');
        formControl.className = 'form-control error';
        small.innerText = message;
        small.style.display = 'block';
    };

    const setSuccess = (element) => {
        const formControl = element.parentElement;
        formControl.className = 'form-control success';
        const small = formControl.querySelector('small');
        small.style.display = 'none';
    };

    form.addEventListener('submit', function (e) {
        e.preventDefault();

        const firstname = document.getElementById('firstname');
        const lastname = document.getElementById('lastname');
        const email = document.getElementById('email');
        const departmentId = document.getElementById('department_id');
        const departmentName = document.getElementById('department_name');
        const institution = document.getElementById('institution');
        const password = document.getElementById('password');
        const confirmPassword = document.getElementById('confirm_password');
        const terms = document.getElementById('terms');

        let isValid = true;

        // Firstname validation
        const firstNameResult = validateName(firstname.value.trim());
        if (!firstNameResult.isValid) {
            setError(firstname, firstNameResult.message);
            isValid = false;
        } else {
            setSuccess(firstname);
        }

        // Lastname validation
        const lastNameResult = validateName(lastname.value.trim());
        if (!lastNameResult.isValid) {
            setError(lastname, lastNameResult.message);
            isValid = false;
        } else {
            setSuccess(lastname);
        }

        // Email validation
        if (!validateEmail(email.value.trim())) {
            setError(email, 'Please enter a valid email address');
            isValid = false;
        } else {
            setSuccess(email);
        }

        // Department ID validation
        if (!departmentId.value.trim()) {
            setError(departmentId, 'Department ID cannot be empty');
            isValid = false;
        } else {
            setSuccess(departmentId);
        }

        // Department Name validation
        if (!departmentName.value.trim()) {
            setError(departmentName, 'Department name cannot be empty');
            isValid = false;
        } else {
            setSuccess(departmentName);
        }

        // Institution validation
        if (!institution.value.trim()) {
            setError(institution, 'Institution name cannot be empty');
            isValid = false;
        } else {
            setSuccess(institution);
        }

        // Password validation
        if (!validatePassword(password.value)) {
            setError(password, 'Password must be at least 8 characters and contain uppercase, lowercase, number and special character');
            isValid = false;
        } else {
            setSuccess(password);
        }

        // Confirm password validation
        if (confirmPassword.value !== password.value) {
            setError(confirmPassword, 'Passwords do not match');
            isValid = false;
        } else if (confirmPassword.value === '') {
            setError(confirmPassword, 'Please confirm your password');
            isValid = false;
        } else {
            setSuccess(confirmPassword);
        }

        // Terms validation
        if (!terms.checked) {
            setError(terms, 'Please accept the terms and conditions');
            isValid = false;
        } else {
            setSuccess(terms);
        }

        // // If all validations pass, submit the form
        // if (isValid) {
        //     form.submit();
        // }

        // Replace the existing form submission code with this:
        if (isValid) {
            // Disable the submit button to prevent double submission
            document.querySelector('.auth-btn').disabled = true;

            // Remove validation classes from checkbox
            const termsParent = terms.closest('.form-control');
            termsParent.className = 'form-control checkbox';

            // Small delay before submitting (optional)
            setTimeout(() => {
                form.submit();
            }, 100);
        }








    });

    // Real-time validation as user types
    form.querySelectorAll('input').forEach(input => {
        input.addEventListener('input', function () {
            if (this.value.trim() !== '') {
                if (this.id === 'firstname' || this.id === 'lastname') {
                    const nameResult = validateName(this.value.trim());
                    if (!nameResult.isValid) {
                        setError(this, nameResult.message);
                    } else {
                        setSuccess(this);
                    }
                }
            }
        });
    });
});