document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('addStudentForm');

    // Validation Patterns
    const patterns = {
        name: /^[A-Za-z\s]{2,}$/,
        email: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
        studentId: /^[A-Za-z0-9]{5,}$/,
        password: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*(),.?":{}|<>])[A-Za-z\d!@#$%^&*(),.?":{}|<>]{8,}$/
    };

    // Error Messages
    const errorMessages = {
        name: 'Name must contain only letters and be at least 2 characters long',
        email: 'Please enter a valid email address',
        studentId: 'Student ID must be at least 5 characters long and can contain only letters and numbers',
        password: 'Password must be at least 8 characters long and contain at least one uppercase letter, one lowercase letter, one number, and one special character',
        passwordMatch: 'Passwords do not match'
    };

    // Set Error
    function setError(element, message) {
        const formGroup = element.parentElement;
        const errorDisplay = formGroup.querySelector('.error-message');
        
        formGroup.classList.add('error');
        errorDisplay.textContent = message;
    }

    // Set Success
    function setSuccess(element) {
        const formGroup = element.parentElement;
        const errorDisplay = formGroup.querySelector('.error-message');
        
        formGroup.classList.remove('error');
        errorDisplay.textContent = '';
    }

    // Real-time validation
    const inputs = form.querySelectorAll('input, select');
    inputs.forEach(input => {
        input.addEventListener('input', function() {
            validateField(this);
        });

        input.addEventListener('blur', function() {
            validateField(this);
        });
    });

    // Validate individual field
    function validateField(field) {
        const fieldValue = field.value.trim();

        switch(field.id) {
            case 'fname':
            case 'lname':
                if (!patterns.name.test(fieldValue)) {
                    setError(field, errorMessages.name);
                } else {
                    setSuccess(field);
                }
                break;

            case 'email':
                if (!patterns.email.test(fieldValue)) {
                    setError(field, errorMessages.email);
                } else {
                    setSuccess(field);
                }
                break;

            case 'student_id':
                if (!patterns.studentId.test(fieldValue)) {
                    setError(field, errorMessages.studentId);
                } else {
                    setSuccess(field);
                }
                break;

            case 'password':
                if (!patterns.password.test(fieldValue)) {
                    setError(field, errorMessages.password);
                } else {
                    setSuccess(field);
                }
                // Check confirm password match if it has a value
                const confirmPassword = document.getElementById('confirm_password');
                if (confirmPassword.value.trim()) {
                    validateField(confirmPassword);
                }
                break;

            case 'confirm_password':
                const password = document.getElementById('password');
                if (fieldValue !== password.value) {
                    setError(field, errorMessages.passwordMatch);
                } else {
                    setSuccess(field);
                }
                break;

            case 'program':
            case 'year':
                if (!fieldValue) {
                    setError(field, 'This field is required');
                } else {
                    setSuccess(field);
                }
                break;
        }
    }

    // Form Submit Handler
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        let isValid = true;

        // Validate all fields
        inputs.forEach(input => {
            validateField(input);
            if (input.parentElement.classList.contains('error')) {
                isValid = false;
            }
        });

        if (isValid) {
            const submitButton = form.querySelector('.btn-submit');
            submitButton.disabled = true;
            submitButton.classList.add('loading');
            
            // Submit the form
            this.submit();
        } else {
            // Scroll to first error
            const firstError = form.querySelector('.error');
            if (firstError) {
                firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
        }
    });

    // Reset form handler
    const resetButton = form.querySelector('.btn-reset');
    if (resetButton) {
        resetButton.addEventListener('click', function() {
            inputs.forEach(input => {
                setSuccess(input);
            });
        });
    }
});