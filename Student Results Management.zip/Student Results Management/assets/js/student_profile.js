document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('profile-form');

    // Validation functions
    const validateName = (name) => {
        if (!name || name.trim() === '') {
            return { isValid: false, message: 'Name cannot be empty' };
        }
        // Check if contains only letters and spaces
        const nameRegex = /^[A-Za-z\s]+$/;
        if (!nameRegex.test(name)) {
            return { isValid: false, message: 'Name must contain only letters' };
        }
        return { isValid: true, message: '' };
    };

    const validateEmail = (email) => {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!email || email.trim() === '') {
            return { isValid: false, message: 'Email cannot be empty' };
        }
        if (!emailRegex.test(email)) {
            return { isValid: false, message: 'Please enter a valid email address' };
        }
        return { isValid: true, message: '' };
    };

    const validatePassword = (password) => {
        if (!password) return { isValid: true, message: '' }; // Password is optional
        if (password.length < 8) {
            return { isValid: false, message: 'Password must be at least 8 characters long' };
        }
        // Check for uppercase, lowercase, number and special character
        const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*(),.?":{}|<>])[A-Za-z\d!@#$%^&*(),.?":{}|<>]{8,}$/;
        if (!passwordRegex.test(password)) {
            return { isValid: false, message: 'Password must contain uppercase, lowercase, number and special character' };
        }
        return { isValid: true, message: '' };
    };

    const setError = (element, message) => {
        const formGroup = element.closest('.form-group');
        const small = formGroup.querySelector('small') || document.createElement('small');
        formGroup.classList.add('error');
        small.innerText = message;
        small.className = 'error-message';
        if (!formGroup.querySelector('small')) {
            formGroup.appendChild(small);
        }
    };

    const setSuccess = (element) => {
        const formGroup = element.closest('.form-group');
        formGroup.classList.remove('error');
        const small = formGroup.querySelector('small');
        if (small) {
            small.remove();
        }
    };

    // Form submission handling
    form.addEventListener('submit', function(e) {
        e.preventDefault();

        const fname = document.getElementById('fname');
        const lname = document.getElementById('lname');
        const email = document.getElementById('email');
        const currentPassword = document.getElementById('current_password');
        const newPassword = document.getElementById('new_password');
        const confirmPassword = document.getElementById('confirm_password');

        let isValid = true;

        // First Name validation
        const firstNameResult = validateName(fname.value.trim());
        if (!firstNameResult.isValid) {
            setError(fname, firstNameResult.message);
            isValid = false;
        } else {
            setSuccess(fname);
        }

        // Last Name validation
        const lastNameResult = validateName(lname.value.trim());
        if (!lastNameResult.isValid) {
            setError(lname, lastNameResult.message);
            isValid = false;
        } else {
            setSuccess(lname);
        }

        // Email validation
        const emailResult = validateEmail(email.value.trim());
        if (!emailResult.isValid) {
            setError(email, emailResult.message);
            isValid = false;
        } else {
            setSuccess(email);
        }

        // Password validation (only if changing password)
        if (currentPassword.value || newPassword.value || confirmPassword.value) {
            if (!currentPassword.value) {
                setError(currentPassword, 'Please enter your current password');
                isValid = false;
            } else {
                setSuccess(currentPassword);
            }

            const passwordResult = validatePassword(newPassword.value);
            if (!passwordResult.isValid) {
                setError(newPassword, passwordResult.message);
                isValid = false;
            } else {
                setSuccess(newPassword);
            }

            if (newPassword.value !== confirmPassword.value) {
                setError(confirmPassword, 'Passwords do not match');
                isValid = false;
            } else {
                setSuccess(confirmPassword);
            }
        }

        // If validation passes, submit the form
        if (isValid) {
            const saveBtn = form.querySelector('.save-btn');
            saveBtn.disabled = true;
            saveBtn.classList.add('loading');

            // Submit form
            form.submit();
        }
    });

    // Real-time validation
    const inputs = form.querySelectorAll('input:not([readonly])');
    inputs.forEach(input => {
        input.addEventListener('input', function() {
            if (this.id === 'fname' || this.id === 'lname') {
                const nameResult = validateName(this.value.trim());
                if (!nameResult.isValid) {
                    setError(this, nameResult.message);
                } else {
                    setSuccess(this);
                }
            } else if (this.id === 'email') {
                const emailResult = validateEmail(this.value.trim());
                if (!emailResult.isValid) {
                    setError(this, emailResult.message);
                } else {
                    setSuccess(this);
                }
            }
        });
    });

    // Password matching validation in real-time
    const newPassword = document.getElementById('new_password');
    const confirmPassword = document.getElementById('confirm_password');
    
    confirmPassword.addEventListener('input', function() {
        if (this.value && this.value !== newPassword.value) {
            setError(this, 'Passwords do not match');
        } else {
            setSuccess(this);
        }
    });
});