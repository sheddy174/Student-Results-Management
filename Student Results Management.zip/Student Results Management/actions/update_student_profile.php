<?php
session_start();
require_once '../db/config.php';

// Check if user is logged in and is a student
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: ../view/login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $student_id = $_SESSION['user_id'];
    $fname = trim($_POST['fname']);
    $lname = trim($_POST['lname']);
    $email = trim($_POST['email']);
    $current_password = isset($_POST['current_password']) ? $_POST['current_password'] : '';
    $new_password = isset($_POST['new_password']) ? $_POST['new_password'] : '';
    $confirm_password = isset($_POST['confirm_password']) ? $_POST['confirm_password'] : '';

    $errors = [];

    // Basic validation
    if (empty($fname)) {
        $errors[] = "First name is required";
    }
    if (!preg_match("/^[a-zA-Z\s]+$/", $fname)) {
        $errors[] = "First name must contain only letters";
    }

    if (empty($lname)) {
        $errors[] = "Last name is required";
    }
    if (!preg_match("/^[a-zA-Z\s]+$/", $lname)) {
        $errors[] = "Last name must contain only letters";
    }

    if (empty($email)) {
        $errors[] = "Email is required";
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format";
    }

    // Check if email already exists (excluding current user)
    $stmt = $conn->prepare("SELECT id FROM students WHERE email = ? AND id != ?");
    $stmt->bind_param("si", $email, $student_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $errors[] = "Email already in use by another account";
    }
    $stmt->close();

    // Password validation (if changing password)
    if (!empty($current_password)) {
        // Verify current password
        $stmt = $conn->prepare("SELECT password FROM students WHERE id = ?");
        $stmt->bind_param("i", $student_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();
        $stmt->close();

        if (!password_verify($current_password, $user['password'])) {
            $errors[] = "Current password is incorrect";
        }

        // Validate new password
        if (empty($new_password)) {
            $errors[] = "New password is required when changing password";
        } elseif (strlen($new_password) < 8) {
            $errors[] = "New password must be at least 8 characters long";
        } elseif (!preg_match("/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*(),.?\":{}|<>])[A-Za-z\d!@#$%^&*(),.?\":{}|<>]{8,}$/", $new_password)) {
            $errors[] = "New password must contain at least one uppercase letter, one lowercase letter, one number, and one special character";
        }

        if ($new_password !== $confirm_password) {
            $errors[] = "New passwords do not match";
        }
    }

    // If there are any errors, redirect back with error messages
    if (!empty($errors)) {
        $_SESSION['errors'] = $errors;
        header("Location: ../view/student/profile.php");
        exit();
    }

    try {
        $conn->begin_transaction();

        // Update basic information
        $stmt = $conn->prepare("UPDATE students SET fname = ?, lname = ?, email = ? WHERE id = ?");
        $stmt->bind_param("sssi", $fname, $lname, $email, $student_id);
        $stmt->execute();
        $stmt->close();

        // Update password if provided
        if (!empty($new_password)) {
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("UPDATE students SET password = ? WHERE id = ?");
            $stmt->bind_param("si", $hashed_password, $student_id);
            $stmt->execute();
            $stmt->close();
        }

        $conn->commit();

        // Update session variables
        $_SESSION['fname'] = $fname;
        $_SESSION['lname'] = $lname;
        $_SESSION['email'] = $email;

        $_SESSION['success'] = "Profile updated successfully";
        header("Location: ../view/student/profile.php");
        exit();

    } catch (Exception $e) {
        $conn->rollback();
        $_SESSION['errors'] = ["An error occurred while updating your profile. Please try again."];
        header("Location: ../view/student/profile.php");
        exit();
    }
}

// If not POST request, redirect to profile page
header("Location: ../view/student/profile.php");
exit();
?>