<?php
session_start();
require_once '../../db/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $course_code = strtoupper(trim($_POST['course_code']));
    $course_name = trim($_POST['course_name']);
    $department_id = trim($_POST['department_id']);
    $credit_hours = (int)$_POST['credit_hours'];
    $description = trim($_POST['description'] ?? '');

    $errors = [];

    // Validate inputs
    if (empty($course_code) || !preg_match('/^[A-Z0-9-]{2,10}$/', $course_code)) {
        $errors[] = "Invalid course code format";
    }

    if (empty($course_name) || strlen($course_name) < 3) {
        $errors[] = "Course name must be at least 3 characters long";
    }

    if ($credit_hours < 1 || $credit_hours > 6) {
        $errors[] = "Credit hours must be between 1 and 6";
    }

    // Check if course code already exists
    $stmt = $conn->prepare("SELECT course_code FROM courses WHERE course_code = ?");
    $stmt->bind_param("s", $course_code);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $errors[] = "Course code already exists";
    }
    $stmt->close();

    if (!empty($errors)) {
        $_SESSION['error'] = implode("<br>", $errors);
        header("Location: ../../view/admin/courses/add.php");
        exit();
    }

    // Insert course
    $stmt = $conn->prepare("INSERT INTO courses (course_code, course_name, department_id, credit_hours, description) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssis", $course_code, $course_name, $department_id, $credit_hours, $description);

    if ($stmt->execute()) {
        $_SESSION['success'] = "Course added successfully";
        header("Location: ../../view/admin/courses/index.php");
    } else {
        $_SESSION['error'] = "Error adding course: " . $stmt->error;
        header("Location: ../../view/admin/courses/add.php");
    }

    $stmt->close();
    $conn->close();
} else {
    header("Location: ../../view/admin/courses/index.php");
}
?>