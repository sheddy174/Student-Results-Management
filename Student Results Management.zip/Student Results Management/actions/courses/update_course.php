<?php
session_start();
require_once '../../db/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $original_code = $_POST['original_code'];
    $course_code = strtoupper(trim($_POST['course_code']));
    $course_name = trim($_POST['course_name']);
    $department_id = trim($_POST['department_id']);
    $credit_hours = (int)$_POST['credit_hours'];
    $description = trim($_POST['description'] ?? '');

    $errors = [];

    // Validate inputs
    if (empty($course_code) || !preg_match('/^[A-Z0-9-]{2,10}$/', $course_code)) {
        $errors[] = "Invalid course code format";
    }

    if (empty($course_name) || strlen($course_name) < 3) {
        $errors[] = "Course name must be at least 3 characters long";
    }

    if ($credit_hours < 1 || $credit_hours > 6) {
        $errors[] = "Credit hours must be between 1 and 6";
    }

    // Check if new course code already exists (if changed)
    if ($course_code !== $original_code) {
        $stmt = $conn->prepare("SELECT course_code FROM courses WHERE course_code = ?");
        $stmt->bind_param("s", $course_code);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $errors[] = "New course code already exists";
        }
        $stmt->close();
    }

    if (!empty($errors)) {
        $_SESSION['error'] = implode("<br>", $errors);
        header("Location: ../../views/admin/courses/update_course.php?code=" . urlencode($original_code));
        exit();
    }

    try {
        $conn->begin_transaction();

        // Update course information
        $stmt = $conn->prepare("
            UPDATE courses 
            SET course_code = ?, course_name = ?, department_id = ?, 
                credit_hours = ?, description = ? 
            WHERE course_code = ?
        ");
        $stmt->bind_param("sssiss", $course_code, $course_name, $department_id, 
                         $credit_hours, $description, $original_code);
        $stmt->execute();

        // If course code changed, update related records
        if ($course_code !== $original_code) {
            $stmt = $conn->prepare("
                UPDATE results 
                SET course_code = ? 
                WHERE course_code = ?
            ");
            $stmt->bind_param("ss", $course_code, $original_code);
            $stmt->execute();
        }

        $conn->commit();
        $_SESSION['success'] = "Course updated successfully";
        header("Location: ../../view/admin/courses/index.php");

    } catch (Exception $e) {
        $conn->rollback();
        $_SESSION['error'] = "Error updating course: " . $e->getMessage();
        header("Location: ../../view/admin/courses/edit.php?code=" . urlencode($original_code));
    }

    $stmt->close();
    $conn->close();
} else {
    header("Location: ../../view/admin/courses/index.php");
}
?>