<?php
session_start();
require_once '../../db/config.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);
// Check if user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../../login.php");
    exit();
}

// Check if course code is provided
if (!isset($_GET['code']) || empty($_GET['code'])) {
    $_SESSION['error'] = "No course specified for deletion";
    header("Location: ../../view/admin/courses/index.php");
    exit();
}



$course_code = $_GET['code'];

try {
    // Start transaction
    $conn->begin_transaction();

    // First, get course details for confirmation message
    $stmt = $conn->prepare("SELECT course_code, course_name FROM courses WHERE course_code = ?");
    $stmt->bind_param("s", $course_code);
    $stmt->execute();
    $course = $stmt->get_result()->fetch_assoc();

    if (!$course) {
        throw new Exception("Course not found");
    }

    // Check if the course has any associated results
    $stmt = $conn->prepare("SELECT COUNT(*) as result_count FROM results WHERE course_code = ?");
    $stmt->bind_param("s", $course_code);
    $stmt->execute();
    $result_count = $stmt->get_result()->fetch_assoc()['result_count'];

    if ($result_count > 0) {
        // Delete associated results first
        $stmt = $conn->prepare("DELETE FROM results WHERE course_code = ?");
        $stmt->bind_param("s", $course_code);
        $stmt->execute();
        
        // Log the deletion of results (optional)
        $deleted_results = $result_count;
    }

    // Now delete the course
    $stmt = $conn->prepare("DELETE FROM courses WHERE course_code = ?");
    $stmt->bind_param("s", $course_code);
    
    if ($stmt->execute() && $stmt->affected_rows > 0) {
        $conn->commit();
        
        $success_message = sprintf(
            "Course '%s - %s' has been deleted successfully.", 
            $course['course_code'], 
            $course['course_name']
        );
        
        if (isset($deleted_results)) {
            $success_message .= sprintf(
                " %d associated result%s also removed.", 
                $deleted_results,
                $deleted_results > 1 ? 's were' : ' was'
            );
        }
        
        $_SESSION['success'] = $success_message;
    } else {
        throw new Exception("Failed to delete course");
    }

} catch (Exception $e) {
    // Rollback on error
    $conn->rollback();
    $_SESSION['error'] = "Error deleting course: " . $e->getMessage();
} finally {
    if (isset($stmt)) {
        $stmt->close();
    }
    $conn->close();
}

// Redirect back to courses list
header("Location: ../../view/admin/courses/index.php");
exit();
?>