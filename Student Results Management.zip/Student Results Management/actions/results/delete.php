<?php
session_start();
require_once '../../db/config.php';

// Check if user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../../login.php");
    exit();
}

// Check if result ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['error'] = "No result specified for deletion";
    header("Location: ../../view/admin/results/index.php");
    exit();
}

$result_id = $_GET['id'];

try {
    // Start transaction
    $conn->begin_transaction();

    // First, get result details for confirmation message
    $stmt = $conn->prepare("
        SELECT r.*, s.student_id as student_number, s.fname, s.lname, c.course_name 
        FROM results r
        JOIN students s ON r.student_id = s.id
        JOIN courses c ON r.course_code = c.course_code
        WHERE r.id = ?
    ");
    $stmt->bind_param("i", $result_id);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();

    if (!$result) {
        throw new Exception("Result not found");
    }

    // Delete the result
    $stmt = $conn->prepare("DELETE FROM results WHERE id = ?");
    $stmt->bind_param("i", $result_id);
    
    if ($stmt->execute() && $stmt->affected_rows > 0) {
        $conn->commit();
        $_SESSION['success'] = sprintf(
            "Result deleted successfully for student %s %s (%s) in course %s",
            $result['fname'],
            $result['lname'],
            $result['student_number'],
            $result['course_name']
        );
    } else {
        throw new Exception("Failed to delete result");
    }

} catch (Exception $e) {
    // Rollback on error
    $conn->rollback();
    $_SESSION['error'] = "Error deleting result: " . $e->getMessage();
} finally {
    if (isset($stmt)) {
        $stmt->close();
    }
    $conn->close();
}





// Redirect back to results list
header("Location: ../../view/admin/results/index.php");
exit();
?>