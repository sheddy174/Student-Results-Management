<?php
session_start();
require_once '../../db/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $result_id = $_POST['result_id'];
    $grade = $_POST['grade'];
    $exam_date = $_POST['exam_date'];

    $errors = [];

    // Validate inputs
    if (empty($grade) || empty($exam_date)) {
        $errors[] = "All fields are required";
    }

    if (!empty($errors)) {
        $_SESSION['error'] = implode("<br>", $errors);
        header("Location: ../../view/admin/results/edit.php?id=" . $result_id);
        exit();
    }

    // Update result
    $stmt = $conn->prepare("UPDATE results SET grade = ?, exam_date = ? WHERE id = ?");
    $stmt->bind_param("ssi", $grade, $exam_date, $result_id);

    if ($stmt->execute()) {
        $_SESSION['success'] = "Result updated successfully";
        header("Location: ../../view/admin/results/index.php");
    } else {
        $_SESSION['error'] = "Error updating result: " . $stmt->error;
        header("Location: ../../view/admin/results/edit.php?id=" . $result_id);
    }

    $stmt->close();
    $conn->close();
} else {
    header("Location: ../../view/admin/results/index.php");
}
?>