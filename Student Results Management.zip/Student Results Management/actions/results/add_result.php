<?php
session_start();
require_once '../../db/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $student_id = $_POST['student_id'];
    $course_code = $_POST['course_code'];
    $semester = $_POST['semester'];
    $grade = $_POST['grade'];
    $exam_date = $_POST['exam_date'];
    $created_by = $_SESSION['user_id'];

    $errors = [];

    // Validate inputs
    if (empty($student_id) || empty($course_code) || empty($semester) || empty($grade) || empty($exam_date)) {
        $errors[] = "All fields are required";
    }

    // Validate and format date
    if (!empty($exam_date)) {
        // Try to create a DateTime object to ensure valid date
        try {
            $dateObj = new DateTime($exam_date);
            $formatted_exam_date = $dateObj->format('Y-m-d');
            
            // Calculate academic year based on exam date
            $academic_year = $dateObj->format('Y') . '-' . ($dateObj->format('Y') + 1);
        } catch (Exception $e) {
            $errors[] = "Invalid date format";
        }
    } else {
        $errors[] = "Exam date is required";
    }

    // Calculate grade point based on letter grade
    function calculateGradePoint($grade) {
        switch ($grade) {
            case 'A+': return 4.0;
            case 'A':  return 4.0;
            case 'B+': return 3.5;
            case 'B':  return 3.0;
            case 'C+': return 2.5;
            case 'C':  return 2.0;
            case 'D':  return 1.5;
            case 'E':  return 1.0;
            case 'F':  return 0.0;
            default:   return 0.0;
        }
    }
    $grade_point = calculateGradePoint($grade);

    // Fetch course name from courses table
    $course_stmt = $conn->prepare("SELECT course_name FROM courses WHERE course_code = ?");
    $course_stmt->bind_param("s", $course_code);
    $course_stmt->execute();
    $course_result = $course_stmt->get_result();
    
    if ($course_result->num_rows === 0) {
        $errors[] = "Invalid course code";
    } else {
        $course_data = $course_result->fetch_assoc();
        $course_name = $course_data['course_name'];
    }
    $course_stmt->close();

    // Check if result already exists for this student and course
    $stmt = $conn->prepare("SELECT id FROM results WHERE student_id = ? AND course_code = ? AND semester = ?");
    $stmt->bind_param("isi", $student_id, $course_code, $semester);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $errors[] = "A result already exists for this student in this course and semester";
    }
    $stmt->close();

    if (!empty($errors)) {
        $_SESSION['error'] = implode("<br>", $errors);
        header("Location: ../../view/admin/results/add.php");
        exit();
    }

    // Prepare and execute insert statement
    $stmt = $conn->prepare("INSERT INTO results (student_id, course_code, course_name, semester, grade, grade_point, exam_date, academic_year, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    
    // Carefully count the variables and match type specifiers
    $stmt->bind_param("issssdssi", 
        $student_id,       // i (integer)
        $course_code,      // s (string)
        $course_name,      // s (string)
        $semester,         // s (string)
        $grade,            // s (string)
        $grade_point,      // d (double/float)
        $formatted_exam_date, // s (string)
        $academic_year,    // s (string)
        $created_by        // i (integer)
    );

    if ($stmt->execute()) {
        $_SESSION['success'] = "Result added successfully";
        header("Location: ../../view/admin/results/index.php");
    } else {
        $_SESSION['error'] = "Error adding result: " . $stmt->error;
        header("Location: ../../view/admin/results/add.php");
    }

    $stmt->close();
    $conn->close();
} else {
    header("Location: ../../view/admin/results/index.php");
}
?>