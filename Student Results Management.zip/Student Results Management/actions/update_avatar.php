<?php
session_start();
require_once '../db/config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['avatar'])) {
    $admin_id = $_SESSION['user_id'];
    $file = $_FILES['avatar'];
    
    // Validate file
    $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
    $max_size = 5 * 1024 * 1024; // 5MB
    
    if (!in_array($file['type'], $allowed_types)) {
        echo json_encode(['success' => false, 'message' => 'Invalid file type']);
        exit();
    }
    
    if ($file['size'] > $max_size) {
        echo json_encode(['success' => false, 'message' => 'File size too large']);
        exit();
    }
    
    // Create avatars directory if it doesn't exist
    $upload_dir = '../assets/images/avatars/';
    if (!file_exists($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }
    
    // Generate unique filename
    $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = 'admin_' . $admin_id . '_' . time() . '.' . $extension;
    $filepath = $upload_dir . $filename;
    
    if (move_uploaded_file($file['tmp_name'], $filepath)) {
        // Update database with new avatar path
        $avatar_url = 'assets/images/avatars/' . $filename;
        $stmt = $conn->prepare("UPDATE admins SET avatar = ? WHERE id = ?");
        $stmt->bind_param("si", $avatar_url, $admin_id);
        
        if ($stmt->execute()) {
            // Delete old avatar if exists
            $old_avatar = $conn->query("SELECT avatar FROM admins WHERE id = $admin_id")->fetch_assoc()['avatar'];
            if ($old_avatar && $old_avatar !== 'assets/images/avatars/default-avatar.png') {
                @unlink('../' . $old_avatar);
            }
            
            echo json_encode([
                'success' => true, 
                'avatar_url' => $avatar_url
            ]);
        } else {
            echo json_encode([
                'success' => false, 
                'message' => 'Database update failed'
            ]);
        }
        
        $stmt->close();
    } else {
        echo json_encode([
            'success' => false, 
            'message' => 'Failed to upload file'
        ]);
    }
} else {
    echo json_encode([
        'success' => false, 
        'message' => 'Invalid request'
    ]);
}
?>