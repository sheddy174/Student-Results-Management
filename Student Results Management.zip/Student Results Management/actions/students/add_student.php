<!-- actions/students/add_student.php -->
<?php
session_start();
require_once '../../db/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $fname = trim($_POST['fname']);
    $lname = trim($_POST['lname']);
    $email = trim($_POST['email']);
    $student_id = trim($_POST['student_id']);
    $program = trim($_POST['program']);
    $year = trim($_POST['year']);
    $institution = $_POST['institution'];
    $password = $_POST['password'];
    

    $errors = [];

    // Validate inputs
    if (empty($fname) || empty($lname)) {
        $errors[] = "Name fields are required";
    }

    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Valid email is required";
    }

    if (empty($student_id)) {
        $errors[] = "Student ID is required";
    }

    if (empty($password)) {
        $errors[] = "Password is required";
    }


    if (empty($institution)) {
        $errors[] = "Institution is required";
    }

    // Check if email or student ID already exists
    $stmt = $conn->prepare("SELECT id FROM students WHERE email = ? OR student_id = ?");
    $stmt->bind_param("ss", $email, $student_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $errors[] = "Email or Student ID already exists";
    }
    $stmt->close();

    if (!empty($errors)) {
        $_SESSION['errors'] = $errors;
        header("Location: ../../views/admin/students/add.php");
        exit();
    }

    // Hash password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Insert new student
    $stmt = $conn->prepare("INSERT INTO students (fname, lname, email, student_id, program, year, institution, password) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssssss", $fname, $lname, $email, $student_id, $program, $year, $institution, $hashed_password);

    if ($stmt->execute()) {
        $_SESSION['success'] = "Student added successfully";
        header("Location: ../../view/admin/students/index.php");
    } else {
        $_SESSION['errors'] = ["Error adding student: " . $stmt->error];
        header("Location: ../../view/admin/students/add.php");
    }

    $stmt->close();
    $conn->close();
} else {
    header("Location: ../../view/admin/students/index.php");
}
?>