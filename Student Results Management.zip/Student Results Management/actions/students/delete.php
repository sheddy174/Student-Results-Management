<?php
header('Content-Type: application/json');
session_start();
require_once '../../../db/config.php';

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Response array
$response = [
    'success' => false,
    'message' => ''
];

// Check if student ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    $response['message'] = "No student specified for deletion";
    echo json_encode($response);
    exit();
}

$student_id = $_GET['id'];

try {
    // Start transaction
    $conn->begin_transaction();

    // First, get student details for confirmation
    $stmt = $conn->prepare("SELECT student_id, fname, lname FROM students WHERE id = ?");
    $stmt->bind_param("i", $student_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $student = $result->fetch_assoc();

    if (!$student) {
        throw new Exception("Student not found");
    }

    // Check if student has any results
    $stmt = $conn->prepare("SELECT COUNT(*) as result_count FROM results WHERE student_id = ?");
    $stmt->bind_param("i", $student_id);
    $stmt->execute();
    $result_count = $stmt->get_result()->fetch_assoc()['result_count'];

    if ($result_count > 0) {
        // Delete associated results first
        $stmt = $conn->prepare("DELETE FROM results WHERE student_id = ?");
        $stmt->bind_param("i", $student_id);
        $stmt->execute();
    }

    // Now delete the student
    $stmt = $conn->prepare("DELETE FROM students WHERE id = ?");
    $stmt->bind_param("i", $student_id);
    
    if ($stmt->execute() && $stmt->affected_rows > 0) {
        $conn->commit();
        $response['success'] = true;
        $response['message'] = "Student " . $student['fname'] . " " . $student['lname'] . " (ID: " . $student['student_id'] . ") has been deleted successfully";
    } else {
        throw new Exception("Failed to delete student");
    }

} catch (Exception $e) {
    $conn->rollback();
    $response['message'] = "Error deleting student: " . $e->getMessage();
} finally {
    if (isset($stmt)) {
        $stmt->close();
    }
    $conn->close();
}

// Output JSON response
echo json_encode($response);
exit();
?>