<?php
session_start();
require_once '../../db/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $student_id = $_POST['student_id'];
    $fname = trim($_POST['fname']);
    $lname = trim($_POST['lname']);
    $email = trim($_POST['email']);
    $program = trim($_POST['program']);
    $year = trim($_POST['year']);
    $new_password = trim($_POST['new_password'] ?? '');

    $errors = [];

    // Validate inputs
    if (empty($fname) || empty($lname)) {
        $errors[] = "Name fields are required";
    }

    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Valid email is required";
    }

    // Check if email exists for other students
    $stmt = $conn->prepare("SELECT id FROM students WHERE email = ? AND id != ?");
    $stmt->bind_param("si", $email, $student_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $errors[] = "Email already exists for another student";
    }
    $stmt->close();

    if (!empty($errors)) {
        $_SESSION['error'] = implode("<br>", $errors);
        header("Location: ../../view/admin/students/edit.php?id=" . $student_id);
        exit();
    }

    // Start transaction
    $conn->begin_transaction();

    try {
        // Update basic information
        $stmt = $conn->prepare("UPDATE students SET fname = ?, lname = ?, email = ?, program = ?, year = ? WHERE id = ?");
        $stmt->bind_param("ssssii", $fname, $lname, $email, $program, $year, $student_id);
        $stmt->execute();

        // Update password if provided
        if (!empty($new_password)) {
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("UPDATE students SET password = ? WHERE id = ?");
            $stmt->bind_param("si", $hashed_password, $student_id);
            $stmt->execute();
        }

        $conn->commit();
        $_SESSION['success'] = "Student information updated successfully";
        header("Location: ../../view/admin/students/edit.php?id=" . $student_id);
        exit();

    } catch (Exception $e) {
        $conn->rollback();
        $_SESSION['error'] = "Error updating student information: " . $e->getMessage();
        header("Location: ../../view/admin/students/edit.php?id=" . $student_id);
        exit();
    }
} else {
    header("Location: ../../view/admin/students/index.php");
    exit();
}
?>