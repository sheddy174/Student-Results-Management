<?php
session_start();
require '../db/config.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form data
    $fname = trim($_POST['fname']);
    $lname = trim($_POST['lname']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $student_id = trim($_POST['student_id']);
    $institution = trim($_POST['institution']);
    $program = trim($_POST['program']);
    $year = trim($_POST['year']);

    // Basic validation
    $errors = [];

    if (empty($fname)) {
        $errors[] = "First name is required";
    }

    if (empty($lname)) {
        $errors[] = "Last name is required";
    }

    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Valid email is required";
    }

    if (empty($password) || strlen($password) < 8) {
        $errors[] = "Password must be at least 8 characters";
    }

    if ($confirm_password !== $password) {
        $errors[] = "Passwords do not match";
    }

    if (empty($student_id)) {
        $errors[] = "Student ID is required";
    }

    // Check for validation errors
    if (!empty($errors)) {
        foreach ($errors as $error) {
            echo "<p style='color: red;'>$error</p>";
        }
        exit;
    }

    // Check if email already exists
    $stmt = $conn->prepare("SELECT email FROM students WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo "<script>alert('Email already registered.');</script>";
        echo "<script>window.location.href = '../view/student_register.php';</script>";
        exit;
    }

    $stmt->close();

    // Check if student ID already exists
    $stmt = $conn->prepare("SELECT student_id FROM students WHERE student_id = ?");
    $stmt->bind_param("s", $student_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo "<script>alert('Student ID already exists.');</script>";
        echo "<script>window.location.href = '../view/student_register.php';</script>";
        exit;
    }

    $stmt->close();

    // Hash password and insert student
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $conn->prepare("INSERT INTO students (fname, lname, email, password, student_id, institution, program, year) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssssi", $fname, $lname, $email, $hashedPassword, $student_id, $institution, $program, $year);

    if ($stmt->execute()) {
        echo "<script>alert('Registration successful!');</script>";
        echo "<script>window.location.href = '../view/login.php';</script>";
    } else {
        echo "<p style='color: red;'>Registration failed: " . $stmt->error . "</p>";
    }

    $stmt->close();
    $conn->close();
}
?>