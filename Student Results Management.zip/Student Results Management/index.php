<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Result Management System</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="./assets/css/index.css">
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar">
        <div class="container mx-auto flex justify-between items-center px-4">
            <div class="navbar-brand">SRMS</div>
            <div class="hidden md:flex space-x-4">
                <a href="index.php" class="nav-link">Home</a>
                <a href="../Student Results Management/view/login.php" class="nav-link">Student Login</a>
                <a href="../Student Results Management/view/login.php" class="nav-link">Admin Login</a>
                <a href="help.php" class="nav-link">Help</a>
            </div>
            <!-- Mobile Menu Button -->
            <button class="md:hidden text-white">
                <i class="fas fa-bars"></i>
            </button>
        </div>
        <!-- Mobile Menu -->
        <div class="hidden md:hidden mobile-menu mt-2 p-4">
            <a href="index.php" class="block text-white py-2">Home</a>
            <a href="../Student Results Management/view/login.php" class="block text-white py-2">Student Login</a>
            <a href="admin/login.php" class="block text-white py-2">Admin Login</a>
            <a href="help.php" class="block text-white py-2">Help</a>
        </div>
    </nav>

    <!-- Hero Section -->
    <header class="hero">
        <div class="hero-content text-center">
            <h1 class="fade-in">Student Result Management System</h1>
            <p class="fade-in">Access your academic results quickly and securely</p>
            <div class="hero-buttons fade-in">
                <a href="../Student Results Management/view/login.php" class="btn-primary">Login Now</a>
                <a href="../Student Results Management/view/register.php" class="btn-secondary">Register Now</a>
            </div>
        </div>
    </header>

    <!-- Features Section -->
    <section class="features">
        <div class="container mx-auto px-4">
            <h2 class="text-3xl font-bold text-center mb-12">Key Features</h2>
            <div class="grid md:grid-cols-3 gap-8">
                <!-- Feature 1 -->
                <div class="feature-card fade-in">
                    <div class="feature-icon">
                        <i class="fas fa-chart-line"></i>
                    </div>
                    <h3>Result Tracking</h3>
                    <p>Access and track your academic performance easily with our intuitive dashboard</p>
                </div>
                <!-- Feature 2 -->
                <div class="feature-card fade-in">
                    <div class="feature-icon">
                        <i class="fas fa-file-download"></i>
                    </div>
                    <h3>Download Reports</h3>
                    <p>Generate and download comprehensive result reports instantly in multiple formats</p>
                </div>
                <!-- Feature 3 -->
                <div class="feature-card fade-in">
                    <div class="feature-icon">
                        <i class="fas fa-lock"></i>
                    </div>
                    <h3>Secure Access</h3>
                    <p>Your academic data is protected with state-of-the-art security measures</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Call to Action -->
    <section class="cta">
        <div class="container mx-auto px-4">
            <h2>Ready to Get Started?</h2>
            <p class="text-xl mb-8">Join thousands of students managing their academic results efficiently</p>
            <a href="../Student Results Management/view/register.php" class="btn-get-started">Get Started Now</a>
        </div>
    </section>

    <!-- How It Works Section -->
    <section class="py-16">
        <div class="container mx-auto px-4">
            <h2 class="text-3xl font-bold text-center mb-12">How It Works</h2>
            <div class="grid md:grid-cols-4 gap-8">
                <!-- Steps with enhanced styling -->
                <div class="step fade-in">
                    <div class="step-number">1</div>
                    <h3>Register</h3>
                    <p>Create your student account</p>
                </div>
                <div class="step fade-in">
                    <div class="step-number">2</div>
                    <h3>Login</h3>
                    <p>Access your dashboard</p>
                </div>
                <div class="step fade-in">
                    <div class="step-number">3</div>
                    <h3>View Results</h3>
                    <p>Check your grades</p>
                </div>
                <div class="step fade-in">
                    <div class="step-number">4</div>
                    <h3>Download</h3>
                    <p>Get your result reports</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container mx-auto px-4">
            <div class="grid md:grid-cols-3 gap-8">
                <div>
                    <h4>Quick Links</h4>
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <li><a href="about.php">About</a></li>
                        <li><a href="contact.php">Contact</a></li>
                    </ul>
                </div>
                <div>
                    <h4>Help & Support</h4>
                    <ul>
                        <li><a href="faq.php">FAQ</a></li>
                        <li><a href="support.php">Support</a></li>
                        <li><a href="privacy.php">Privacy Policy</a></li>
                    </ul>
                </div>
                <div>
                    <h4>Contact Us</h4>
                    <p class="mb-2"><i class="fas fa-envelope"></i> support@srms.com</p>
                    <p><i class="fas fa-phone"></i> (+233) 593-878966</p>
                </div>
            </div>
            <div class="text-center mt-8 pt-8 border-t border-gray-700">
                <p>&copy; 2024 Student Result Management System. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <!-- Mobile Menu Toggle Script -->
    <script>
        // Navbar scroll effect
        window.addEventListener('scroll', function() {
            const navbar = document.querySelector('.navbar');
            if (window.scrollY > 50) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        });

        // Mobile menu toggle
        document.querySelector('button').addEventListener('click', function() {
            document.querySelector('.mobile-menu').classList.toggle('hidden');
        });
    </script>
</body>
</html>