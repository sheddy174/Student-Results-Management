<?php
session_start();
require_once '../../db/config.php';

// Check if user is logged in and is a student
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: ../login.php");
    exit();
}

// Fetch student information
$student_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT * FROM students WHERE id = ?");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$student = $stmt->get_result()->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile - SRMS</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../../assets/css/student_profile.css">
</head>

<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="container">
            <div class="logo">SRMS</div>
            <div class="nav-links">
                <a href="dashboard.php">Dashboard</a>
                <a href="../../view/view_results.php">Results</a>
                <a href="../student/profile.php" class="active">Profile</a>
                <a href="../../actions/logout.php" class="logout-btn">Logout</a>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="container">
        <div class="profile-container">
            <div class="profile-header">
                <h1>My Profile</h1>
                <p>Manage your account information and settings</p>
            </div>



            <!-- Add this after the profile-header div -->
            <?php if (isset($_SESSION['errors'])): ?>
                <div class="message error">
                    <?php
                    foreach ($_SESSION['errors'] as $error) {
                        echo htmlspecialchars($error) . "<br>";
                    }
                    unset($_SESSION['errors']);
                    ?>
                </div>
            <?php endif; ?>

            <?php if (isset($_SESSION['success'])): ?>
                <div class="message success">
                    <?php
                    echo htmlspecialchars($_SESSION['success']);
                    unset($_SESSION['success']);
                    ?>
                </div>
            <?php endif; ?>



            <form action="../../actions/update_student_profile.php" method="POST" id="profile-form">
                <div class="form-sections">
                    <!-- Personal Information Section -->
                    <div class="form-section">
                        <h2>Personal Information</h2>
                        <div class="form-grid">
                            <div class="form-group">
                                <label for="fname">First Name</label>
                                <input type="text" id="fname" name="fname"
                                    value="<?php echo htmlspecialchars($student['fname']); ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="lname">Last Name</label>
                                <input type="text" id="lname" name="lname"
                                    value="<?php echo htmlspecialchars($student['lname']); ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="email">Email</label>
                                <input type="email" id="email" name="email"
                                    value="<?php echo htmlspecialchars($student['email']); ?>" required>
                            </div>
                        </div>
                    </div>

                    <!-- Academic Information Section -->
                    <div class="form-section">
                        <h2>Academic Information</h2>
                        <div class="form-grid">
                            <div class="form-group">
                                <label for="student_id">Student ID</label>
                                <input type="text" id="student_id"
                                    value="<?php echo htmlspecialchars($student['student_id']); ?>"
                                    readonly class="readonly">
                            </div>
                            <div class="form-group">
                                <label for="program">Program</label>
                                <input type="text" id="program"
                                    value="<?php echo htmlspecialchars($student['program']); ?>"
                                    readonly class="readonly">
                            </div>
                            <div class="form-group">
                                <label for="year">Year</label>
                                <input type="text" id="year"
                                    value="<?php echo htmlspecialchars($student['year']); ?>"
                                    readonly class="readonly">
                            </div>
                            <div class="form-group">
                                <label for="institution">Institution</label>
                                <input type="text" id="institution"
                                    value="<?php echo htmlspecialchars($student['institution']); ?>"
                                    readonly class="readonly">
                            </div>
                        </div>
                    </div>

                    <!-- Change Password Section -->
                    <div class="form-section">
                        <h2>Change Password</h2>
                        <div class="form-grid">
                            <div class="form-group">
                                <label for="current_password">Current Password</label>
                                <input type="password" id="current_password" name="current_password">
                            </div>
                            <div class="form-group">
                                <label for="new_password">New Password</label>
                                <input type="password" id="new_password" name="new_password">
                            </div>
                            <div class="form-group">
                                <label for="confirm_password">Confirm New Password</label>
                                <input type="password" id="confirm_password" name="confirm_password">
                            </div>
                        </div>
                    </div>
                </div>

                <div class="form-actions">
                    <button type="submit" class="save-btn">Save Changes</button>
                </div>
            </form>
        </div>
    </div>

    <script src="../../assets/js/student_profile.js"></script>
</body>

</html>