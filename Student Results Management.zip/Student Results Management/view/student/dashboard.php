<?php
session_start();
require_once '../../db/config.php';


ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


// Check if user is logged in and is a student
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: ../login.php");
    exit();
}

// Fetch student information
$student_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT * FROM students WHERE id = ?");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$student = $stmt->get_result()->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard - SRMS</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../../assets/css/student_dashboard.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>

</head>

<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="container">
            <div class="logo">SRMS</div>
            <div class="nav-links">
                <a href="dashboard.php" class="active">Dashboard</a>
                <a href="../../view/view_results.php">Results</a>
                <a href="profile.php">Profile</a>
                <a href="../../actions/logout.php" class="logout-btn">Logout</a>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="container">
        <!-- Welcome Section -->
        <div class="welcome-section">
            <h1>Welcome, <?php echo htmlspecialchars($student['fname'] . ' ' . $student['lname']); ?></h1>
            <p>Student ID: <?php echo htmlspecialchars($student['student_id']); ?></p>
        </div>

        <!-- Quick Actions -->
        <div class="quick-actions">
            <a href="../view_results.php" class="action-card">
                <i class="fas fa-chart-bar"></i>
                <h3>View Results</h3>
                <p>Check your academic performance</p>
            </a>
            <a href="profile.php" class="action-card">
                <i class="fas fa-user"></i>
                <h3>Profile</h3>
                <p>View and update your information</p>
            </a>

            <a href="javascript:void(0);" onclick="downloadResults()" class="action-card">
                <i class="fas fa-download"></i>
                <h3>Download Results</h3>
                <p>Get your result reports</p>
            </a>




            <!-- <a href="download_results.php" class="action-card">
                <i class="fas fa-download"></i>
                <h3>Download Results</h3>
                <p>Get your result reports</p>
            </a> -->
        </div>

        <!-- Recent Results Summary -->
        <div class="recent-results">
            <h2>Recent Results</h2>
            <div class="results-table">
                <table>
                    <thead>
                        <tr>
                            <th>Course Code</th>
                            <th>Course Name</th>
                            <th>Grade</th>
                            <th>Semester</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        // Fetch recent results
                        $stmt = $conn->prepare("SELECT * FROM results WHERE student_id = ? ORDER BY created_at DESC LIMIT 5");
                        $stmt->bind_param("i", $student_id);
                        $stmt->execute();
                        $results = $stmt->get_result();

                        while ($result = $results->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . htmlspecialchars($result['course_code']) . "</td>";
                            echo "<td>" . htmlspecialchars($result['course_name']) . "</td>";
                            echo "<td>" . htmlspecialchars($result['grade']) . "</td>";
                            echo "<td>" . htmlspecialchars($result['semester']) . "</td>";
                            echo "</tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Add this JavaScript at the bottom of dashboard.php, before </body> -->
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script> -->
    <script>
        function downloadResults() {
            // Create a container for the PDF content
            const pdfContainer = document.createElement('div');
            pdfContainer.style.padding = '20px';
            pdfContainer.style.fontFamily = 'Arial, sans-serif';

            // Add header information
            const headerContent = `
        <div style="text-align: center; margin-bottom: 20px;">
            <h1>STUDENT RESULT REPORT</h1>
            <p><strong>Student Name:</strong> ${<?php echo json_encode($student['fname'] . ' ' . $student['lname']); ?>}</p>
            <p><strong>Student ID:</strong> ${<?php echo json_encode($student['student_id']); ?>}</p>
            <p><strong>Date:</strong> ${new Date().toLocaleDateString()}</p>
        </div>
    `;
            pdfContainer.innerHTML += headerContent;

            // Create table for results
            const tableContent = `
        <table style="width: 100%; border-collapse: collapse;">
            <thead>
                <tr style="background-color: #f2f2f2;">
                    <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Course Code</th>
                    <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Course Name</th>
                    <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Grade</th>
                    <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Semester</th>
                </tr>
            </thead>
            <tbody>
                ${Array.from(document.querySelectorAll('table tbody tr'))
                    .map(row => `
                        <tr>
                            <td style="border: 1px solid #ddd; padding: 8px;">${row.cells[0].textContent}</td>
                            <td style="border: 1px solid #ddd; padding: 8px;">${row.cells[1].textContent}</td>
                            <td style="border: 1px solid #ddd; padding: 8px;">${row.cells[2].textContent}</td>
                            <td style="border: 1px solid #ddd; padding: 8px;">${row.cells[3].textContent}</td>
                        </tr>
                    `).join('')}
            </tbody>
        </table>
    `;
            pdfContainer.innerHTML += tableContent;

            // Configuration for html2pdf
            const opt = {
                margin: 10,
                filename: `Recent_Results_${<?php echo json_encode($student['student_id']); ?>}_${new Date().toISOString().split('T')[0]}.pdf`,
                image: {
                    type: 'jpeg',
                    quality: 0.98
                },
                html2canvas: {
                    scale: 2
                },
                jsPDF: {
                    unit: 'mm',
                    format: 'a4',
                    orientation: 'portrait'
                }
            };

            // Generate and download PDF
            html2pdf().set(opt).from(pdfContainer).save();
        }
    </script>

</body>

</html>