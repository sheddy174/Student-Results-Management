<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Registration - SRMS</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/student_register.css">
</head>

<body>
    <div class="container">
        <h2>Student Registration</h2>
        <form id="signup-form" action="../actions/student_register.php" method="POST" onsubmit="return validateStudentForm()">
            <!-- Personal Information -->
            <div class="form-control">
                <input type="text" id="firstname" name="fname" placeholder="Enter your firstname" required>
                <i class="fas fa-check-circle"></i>
                <i class="fas fa-exclamation-circle"></i>
                <small></small>
            </div>

            <div class="form-control">
                <input type="text" id="lastname" name="lname" placeholder="Enter your lastname" required>
                <i class="fas fa-check-circle"></i>
                <i class="fas fa-exclamation-circle"></i>
                <small></small>
            </div>

            <div class="form-control">
                <input type="email" id="email" name="email" placeholder="Enter your email" required>
                <i class="fas fa-check-circle"></i>
                <i class="fas fa-exclamation-circle"></i>
                <small></small>
            </div>

            <!-- Academic Information -->
            <div class="form-control">
                <input type="text" id="student_id" name="student_id" placeholder="Enter Student ID" required>
                <i class="fas fa-check-circle"></i>
                <i class="fas fa-exclamation-circle"></i>
                <small></small>
            </div>

            <div class="form-control">
                <input type="text" id="institution" name="institution" placeholder="Enter Institution Name" required>
                <i class="fas fa-check-circle"></i>
                <i class="fas fa-exclamation-circle"></i>
                <small></small>
            </div>

            <div class="form-control">
                <select id="program" name="program" required>
                    <option value="">Select your program</option>
                    <option value="computer_science">Computer Science</option>
                    <option value="engineering">Electrical Engineering</option>
                    <option value="business">Business Administration</option>
                    <option value="business">Computer Engineering</option>
                    <option value="business">Management Information Systems</option>
                    <option value="business">Mechanical Engineering</option>
                    <option value="business">CyberSecurity</option>
                    <option value="business">Database</option>
                    <option value="business">Information Security</option>
                    <option value="business">Data Structures & Algorithms</option>

                </select>
                <small></small>
            </div>

            <div class="form-control">
                <select id="year" name="year" required>
                    <option value="">Select your year</option>
                    <option value="1">First Year</option>
                    <option value="2">Second Year</option>
                    <option value="3">Third Year</option>
                    <option value="4">Fourth Year</option>
                </select>
                <small></small>
            </div>

            <!-- Security Information -->
            <div class="form-control">
                <input type="password" id="password" name="password" placeholder="Create password" required>
                <i class="fas fa-check-circle"></i>
                <i class="fas fa-exclamation-circle"></i>
                <small></small>
            </div>

            <div class="form-control">
                <input type="password" id="confirm_password" name="confirm_password" placeholder="Confirm password" required>
                <i class="fas fa-check-circle"></i>
                <i class="fas fa-exclamation-circle"></i>
                <small></small>
            </div>

            <!-- <div class="form-control checkbox">
                <input type="checkbox" id="terms" required>
                <label for="terms">I accept all terms & conditions</label>
            </div> -->

            <div class="form-control checkbox">
                <input type="checkbox" id="terms" name="terms" required>
                <label for="terms">I accept all terms & conditions</label>
                <small></small>
            </div>





            <button type="submit" class="auth-btn" name="submitBtn" id="submitBtn">Register as Student</button>
        </form>
        <p class="login-link">Already have an account? <a href="../view/login.php">Login now</a></p>
    </div>

    <script src="../assets/js/student_validation.js"></script>
</body>

</html>