<?php
session_start();
require_once '../../../db/config.php';

// Check if user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../../login.php");
    exit();
}

// Pagination
$limit = 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// Search functionality
$search = isset($_GET['search']) ? $_GET['search'] : '';
$searchCondition = '';
$params = [];
$types = '';

if ($search) {
    $searchCondition = "WHERE student_id LIKE ? OR fname LIKE ? OR lname LIKE ? OR email LIKE ? OR program LIKE ?";
    $searchTerm = "%$search%";
    $params = array_fill(0, 5, $searchTerm);
    $types = str_repeat('s', 5);
}

// Get total number of students
$countStmt = $conn->prepare("SELECT COUNT(*) as total FROM students " . $searchCondition);
if (!empty($params)) {
    $countStmt->bind_param($types, ...$params);
}
$countStmt->execute();
$totalStudents = $countStmt->get_result()->fetch_assoc()['total'];
$totalPages = ceil($totalStudents / $limit);

// Get students for current page
$query = "SELECT * FROM students $searchCondition ORDER BY created_at DESC LIMIT ? OFFSET ?";
if (!empty($params)) {
    $params[] = $limit;
    $params[] = $offset;
    $types .= 'ii';
} else {
    $params = [$limit, $offset];
    $types = 'ii';
}

$stmt = $conn->prepare($query);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$students = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Students - SRMS Admin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../../../assets/css/admin_dashboard.css">
    <link rel="stylesheet" href="../../../assets/css/students_manage.css">
</head>
<body>
    <div class="admin-container">
        <!-- Include your sidebar here -->
        <?php include_once '../includes/sidebar.php'; ?>

        <main class="main-content">
            <div class="header">
                <h1>Manage Students</h1>
                <a href="add.php" class="btn-add">
                    <i class="fas fa-plus"></i> Add New Student
                </a>
            </div>

            <!-- Search and Filter Section -->
            <div class="search-section">
                <form action="" method="GET" class="search-form">
                    <div class="search-input">
                        <input type="text" name="search" placeholder="Search students..." value="<?php echo htmlspecialchars($search); ?>">
                        <button type="submit">
                            <i class="fas fa-search"></i>
                        </button>
                    </div>
                </form>
            </div>

            <!-- Students Table -->
            <div class="table-container">
                <?php if ($students->num_rows > 0): ?>
                    <table>
                        <thead>
                            <tr>
                                <th>Student ID</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Program</th>
                                <th>Year</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($student = $students->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($student['student_id']); ?></td>
                                    <td><?php echo htmlspecialchars($student['fname'] . ' ' . $student['lname']); ?></td>
                                    <td><?php echo htmlspecialchars($student['email']); ?></td>
                                    <td><?php echo htmlspecialchars($student['program']); ?></td>
                                    <td><?php echo htmlspecialchars($student['year']); ?></td>
                                    <td class="actions">
                                        <!-- <a href="view.php?id=<//?php echo $student['id']; ?>" class="btn-view" title="View">
                                            <i class="fas fa-eye"></i>
                                        </a> -->
                                        <a href="edit.php?id=<?php echo $student['id']; ?>" class="btn-edit" title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <button onclick="deleteStudent(<?php echo $student['id']; ?>)" class="btn-delete" title="Delete">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>

                    <!-- Pagination -->
                    <?php if ($totalPages > 1): ?>
                        <div class="pagination">
                            <?php if ($page > 1): ?>
                                <a href="?page=<?php echo ($page-1); ?>&search=<?php echo urlencode($search); ?>" class="page-link">
                                    <i class="fas fa-chevron-left"></i> Previous
                                </a>
                            <?php endif; ?>
                            
                            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                                <a href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>" 
                                   class="page-link <?php echo $i === $page ? 'active' : ''; ?>">
                                    <?php echo $i; ?>
                                </a>
                            <?php endfor; ?>
                            
                            <?php if ($page < $totalPages): ?>
                                <a href="?page=<?php echo ($page+1); ?>&search=<?php echo urlencode($search); ?>" class="page-link">
                                    Next <i class="fas fa-chevron-right"></i>
                                </a>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                <?php else: ?>
                    <div class="no-records">
                        <i class="fas fa-user-graduate"></i>
                        <p>No students found</p>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>

    <!-- Delete Confirmation Modal -->
    <div id="deleteModal" class="modal">
        <div class="modal-content">
            <h2>Confirm Deletion</h2>
            <p>Are you sure you want to delete this student? This action cannot be undone.</p>
            <div class="modal-actions">
                <button onclick="confirmDelete()" class="btn-confirm">Yes, Delete</button>
                <button onclick="closeModal()" class="btn-cancel">Cancel</button>
            </div>
        </div>
    </div>

    <script>
        let studentToDelete = null;

        function deleteStudent(studentId) {
            studentToDelete = studentId;
            document.getElementById('deleteModal').style.display = 'flex';
        }

        function closeModal() {
            document.getElementById('deleteModal').style.display = 'none';
        }

        function confirmDelete() {
            if (studentToDelete) {
                window.location.href = `../../../actions/students/delete.php?id=${studentToDelete}`;
            }
        }

        // Close modal when clicking outside
        window.onclick = function(event) {
            const modal = document.getElementById('deleteModal');
            if (event.target == modal) {
                closeModal();
            }
        }
    </script>
</body>
</html>