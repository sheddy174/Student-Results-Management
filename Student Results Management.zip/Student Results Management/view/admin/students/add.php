<!-- views/admin/students/add.php -->
<?php
session_start();
require_once '../../../db/config.php';

// Check if user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../../login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Student - SRMS Admin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../../../assets/css/admin_dashboard.css">
    <link rel="stylesheet" href="../../../assets/css/students_manage.css">
    <link rel="stylesheet" href="../../../assets/css/add_student.css">

</head>

<body>
    <div class="admin-container">
        <!-- Include Sidebar -->
        <?php include_once '../includes/sidebar.php'; ?>

        <!-- Main Content -->
        <main class="main-content">
            <div class="page-header">
                <h1>Add New Student</h1>
                <a href="index.php" class="back-button">
                    <i class="fas fa-arrow-left"></i> Back to List
                </a>
            </div>

            <div class="form-container">
                <form action="../../../actions/students/add_student.php" method="POST" id="addStudentForm">
                    <div class="form-grid">
                        <!-- Personal Information -->
                        <div class="form-section">
                            <h2>Personal Information</h2>
                            <div class="form-group">
                                <label for="fname">First Name *</label>
                                <input type="text" id="fname" name="fname" required>
                                <small class="error-message"></small>
                            </div>

                            <div class="form-group">
                                <label for="lname">Last Name *</label>
                                <input type="text" id="lname" name="lname" required>
                                <small class="error-message"></small>
                            </div>

                            <div class="form-group">
                                <label for="email">Email Address *</label>
                                <input type="email" id="email" name="email" required>
                                <small class="error-message"></small>
                            </div>
                        </div>

                        <!-- Academic Information -->
                        <div class="form-section">
                            <h2>Academic Information</h2>
                            <div class="form-group">
                                <label for="student_id">Student ID *</label>
                                <input type="text" id="student_id" name="student_id" required>
                                <small class="error-message"></small>
                            </div>

                            <div class="form-group">
                                <label for="program">Program *</label>
                                <select id="program" name="program" required>
                                    <option value="">Select Program</option>
                                    <option value="Computer Science">Computer Science</option>
                                    <option value="Engineering">Engineering</option>
                                    <option value="Business Administration">Business Administration</option>
                                    <!-- Add more options as needed -->
                                </select>
                                <small class="error-message"></small>
                            </div>

                            <div class="form-group">
                                <label for="year">Year *</label>
                                <select id="year" name="year" required>
                                    <option value="">Select Year</option>
                                    <option value="1">First Year</option>
                                    <option value="2">Second Year</option>
                                    <option value="3">Third Year</option>
                                    <option value="4">Fourth Year</option>
                                </select>
                                <small class="error-message"></small>
                            </div>



                            <div class="form-group">
                                <label for="institution">Institution *</label>
                                <input type="text" id="institution" name="institution" class="form-control" placeholder="Enter Institution" required>
                                <!-- <select id="institution" name="institution" required>
                                    <option value="">Select Institution</option>
                                    <option value="Main Campus">Main Campus</option>
                                    <option value="Online Campus">Online Campus</option>
                                    <option value="Extension Campus">Extension Campus</option>
                                </select> -->
                                <small class="error-message"></small>
                            </div>

                            <div class="form-group">
                            <label for="credit_hours">Credit Hours *</label>
                            <input type="number" id="credit_hours" name="credit_hours" 
                                   min="1" max="6" required>
                            <small class="helper-text">Enter a value between 1 and 6</small>
                            <small class="error-message"></small>
                        </div>








                            
                        </div>

                        <!-- Account Information -->
                        <div class="form-section">
                            <h2>Account Setup</h2>
                            <div class="form-group">
                                <label for="password">Password *</label>
                                <input type="password" id="password" name="password" required>
                                <small class="error-message"></small>
                            </div>

                            <div class="form-group">
                                <label for="confirm_password">Confirm Password *</label>
                                <input type="password" id="confirm_password" name="confirm_password" required>
                                <small class="error-message"></small>
                            </div>
                        </div>
                    </div>

                    <div class="form-actions">
                        <button type="submit" class="btn-submit">
                            <i class="fas fa-plus"></i> Add Student
                        </button>
                        <button type="reset" class="btn-reset">
                            <i class="fas fa-undo"></i> Reset Form
                        </button>
                    </div>
                </form>
            </div>
        </main>
    </div>

    <script src="../../../assets/js/student_form_validation.js"></script>
</body>

</html>