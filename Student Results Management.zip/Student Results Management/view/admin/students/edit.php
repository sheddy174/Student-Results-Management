<?php
session_start();
require_once '../../../db/config.php';

// Check if user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../../login.php");
    exit();
}

// Check if student ID is provided
if (!isset($_GET['id'])) {
    $_SESSION['error'] = "No student selected for editing";
    header("Location: index.php");
    exit();
}

// Fetch student data
$student_id = $_GET['id'];
$stmt = $conn->prepare("SELECT * FROM students WHERE id = ?");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$result = $stmt->get_result();
$student = $result->fetch_assoc();

if (!$student) {
    $_SESSION['error'] = "Student not found";
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Student - SRMS Admin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../../../assets/css/admin_dashboard.css">
    <link rel="stylesheet" href="../../../assets/css/students_manage.css">
    <link rel="stylesheet" href="../../../assets/css/edit_student.css">

</head>
<body>
    <div class="admin-container">
        <!-- Include Sidebar -->
        <?php include_once '../includes/sidebar.php'; ?>

        <!-- Main Content -->
        <main class="main-content">
            <div class="page-header">
                <h1>Edit Student</h1>
                <a href="index.php" class="back-button">
                    <i class="fas fa-arrow-left"></i> Back to List
                </a>
            </div>

            <!-- Display Success/Error Messages -->
            <?php if (isset($_SESSION['success'])): ?>
                <div class="alert success">
                    <?php 
                        echo $_SESSION['success']; 
                        unset($_SESSION['success']);
                    ?>
                </div>
            <?php endif; ?>

            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert error">
                    <?php 
                        echo $_SESSION['error']; 
                        unset($_SESSION['error']);
                    ?>
                </div>
            <?php endif; ?>

            <div class="form-container">
                <form action="../../../actions/students/update_student.php" method="POST" id="editStudentForm">
                    <input type="hidden" name="student_id" value="<?php echo $student['id']; ?>">
                    
                    <div class="form-grid">
                        <!-- Personal Information -->
                        <div class="form-section">
                            <h2>Personal Information</h2>
                            <div class="form-group">
                                <label for="fname">First Name</label>
                                <input type="text" id="fname" name="fname" 
                                       value="<?php echo htmlspecialchars($student['fname']); ?>" required>
                                <small class="error-message"></small>
                            </div>

                            <div class="form-group">
                                <label for="lname">Last Name</label>
                                <input type="text" id="lname" name="lname" 
                                       value="<?php echo htmlspecialchars($student['lname']); ?>" required>
                                <small class="error-message"></small>
                            </div>

                            <div class="form-group">
                                <label for="email">Email Address</label>
                                <input type="email" id="email" name="email" 
                                       value="<?php echo htmlspecialchars($student['email']); ?>" required>
                                <small class="error-message"></small>
                            </div>
                        </div>

                        <!-- Academic Information -->
                        <div class="form-section">
                            <h2>Academic Information</h2>
                            <div class="form-group">
                                <label>Student ID (Read Only)</label>
                                <input type="text" value="<?php echo htmlspecialchars($student['student_id']); ?>" 
                                       readonly class="readonly">
                            </div>

                            <div class="form-group">
                                <label for="program">Program</label>
                                <select id="program" name="program" required>
                                    <option value="Computer Science" <?php echo $student['program'] == 'Computer Science' ? 'selected' : ''; ?>>
                                        Computer Science
                                    </option>
                                    <option value="Engineering" <?php echo $student['program'] == 'Engineering' ? 'selected' : ''; ?>>
                                        Engineering
                                    </option>
                                    <option value="Business Administration" <?php echo $student['program'] == 'Business Administration' ? 'selected' : ''; ?>>
                                        Business Administration
                                    </option>
                                </select>
                                <small class="error-message"></small>
                            </div>

                            <div class="form-group">
                                <label for="year">Year</label>
                                <select id="year" name="year" required>
                                    <?php for ($i = 1; $i <= 4; $i++): ?>
                                        <option value="<?php echo $i; ?>" <?php echo $student['year'] == $i ? 'selected' : ''; ?>>
                                            Year <?php echo $i; ?>
                                        </option>
                                    <?php endfor; ?>
                                </select>
                                <small class="error-message"></small>
                            </div>
                        </div>

                        <!-- Password Change (Optional) -->
                        <div class="form-section">
                            <h2>Change Password (Optional)</h2>
                            <div class="form-group">
                                <label for="new_password">New Password</label>
                                <input type="password" id="new_password" name="new_password">
                                <small class="error-message"></small>
                            </div>

                            <div class="form-group">
                                <label for="confirm_password">Confirm New Password</label>
                                <input type="password" id="confirm_password" name="confirm_password">
                                <small class="error-message"></small>
                            </div>
                        </div>
                    </div>

                    <div class="form-actions">
                        <button type="submit" class="btn-submit">
                            <i class="fas fa-save"></i> Save Changes
                        </button>
                        <button type="reset" class="btn-reset">
                            <i class="fas fa-undo"></i> Reset Changes
                        </button>
                    </div>
                </form>
            </div>
        </main>
    </div>
    <script src="../../../assets/js/student_form_validation.js"></script>
</body>
</html>