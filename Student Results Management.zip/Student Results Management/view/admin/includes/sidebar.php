<!-- views/admin/includes/sidebar.php -->
<nav class="sidebar">
    <div class="sidebar-header">
        <h2>SRMS Admin</h2>
    </div>
    <ul class="nav-links">
        <li>
            <a href="../dashboard.php">
                <i class="fas fa-home"></i>
                <span>Dashboard</span>
            </a>
        </li>
        <li>
            <a href="../students/">
                <i class="fas fa-users"></i>
                <span>Students</span>
            </a>
        </li>
        <li>
            <a href="../courses/">
                <i class="fas fa-book"></i>
                <span>Courses</span>
            </a>
        </li>
        <li>
            <a href="../results/">
                <i class="fas fa-chart-bar"></i>
                <span>Results</span>
            </a>
        </li>
        <li>
            <a href="../reports/">
                <i class="fas fa-file-alt"></i>
                <span>Reports</span>
            </a>
        </li>
        <li>
            <a href="../profile.php">
                <i class="fas fa-user-cog"></i>
                <span>Profile</span>
            </a>
        </li>
        <li>
            <a href="../../../actions/logout.php">
                <i class="fas fa-sign-out-alt"></i>
                <span>Logout</span>
            </a>
        </li>
    </ul>
</nav>