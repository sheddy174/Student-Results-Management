<?php
session_start();
require_once '../../db/config.php';

// Check if user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

// Fetch admin information
$admin_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT * FROM admins WHERE id = ?");
$stmt->bind_param("i", $admin_id);
$stmt->execute();
$admin = $stmt->get_result()->fetch_assoc();

// Fetch quick statistics
$stats = [
    'total_students' => $conn->query("SELECT COUNT(*) as count FROM students")->fetch_assoc()['count'],
    'total_courses' => $conn->query("SELECT COUNT(*) as count FROM courses")->fetch_assoc()['count'],
    'total_results' => $conn->query("SELECT COUNT(*) as count FROM results")->fetch_assoc()['count']
];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - SRMS</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../../assets/css/admin_dashboard.css">
</head>

<body>
    <!-- Navigation -->
    <div class="admin-container">
        <!-- Sidebar -->
        <nav class="sidebar">
            <div class="sidebar-header">
                <h2>SRMS Admin</h2>
            </div>
            <ul class="nav-links">
                <li class="active">
                    <a href="dashboard.php">
                        <i class="fas fa-home"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="students/">
                        <i class="fas fa-users"></i>
                        <span>Students</span>
                    </a>
                </li>
                <li>
                    <a href="courses/">
                        <i class="fas fa-book"></i>
                        <span>Courses</span>
                    </a>
                </li>
                <li>
                    <a href="results/">
                        <i class="fas fa-chart-bar"></i>
                        <span>Results</span>
                    </a>
                </li>
                <li>
                    <a href="reports/">
                        <i class="fas fa-file-alt"></i>
                        <span>Reports</span>
                    </a>
                </li>
                <li>
                    <a href="profile.php">
                        <i class="fas fa-user-cog"></i>
                        <span>Profile</span>
                    </a>
                </li>
                <li>
                    <a href="../../actions/logout.php">
                        <i class="fas fa-sign-out-alt"></i>
                        <span>Logout</span>
                    </a>
                </li>
            </ul>
        </nav>

        <!-- Main Content -->
        <main class="main-content">
            <!-- Top Bar -->
            <div class="top-bar">
                <div class="toggle-sidebar">
                    <i class="fas fa-bars"></i>
                </div>
                <div class="user-info">
                    <span><?php echo htmlspecialchars($admin['fname'] . ' ' . $admin['lname']); ?></span>
                    <img src="../../assets/images/default-avatar.png" alt="Admin Avatar">
                </div>
            </div>

            <!-- Dashboard Content -->
            <div class="dashboard-content">
                <h1>Welcome, <?php echo htmlspecialchars($admin['fname']); ?>!</h1>

                <!-- Quick Stats -->
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-icon">
                            <i class="fas fa-users"></i>
                        </div>
                        <div class="stat-info">
                            <h3>Total Students</h3>
                            <p><?php echo $stats['total_students']; ?></p>
                        </div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon">
                            <i class="fas fa-book"></i>
                        </div>
                        <div class="stat-info">
                            <h3>Total Courses</h3>
                            <p><?php echo $stats['total_courses']; ?></p>
                        </div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon">
                            <i class="fas fa-chart-bar"></i>
                        </div>
                        <div class="stat-info">
                            <h3>Results Recorded</h3>
                            <p><?php echo $stats['total_results']; ?></p>
                        </div>
                    </div>
                </div>

                <!-- Quick Actions -->
                <div class="quick-actions">
                    <h2>Quick Actions</h2>
                    <div class="actions-grid">
                        <a href="students/add.php" class="action-card">
                            <i class="fas fa-user-plus"></i>
                            <span>Add New Student</span>
                        </a>
                        <a href="courses/add.php" class="action-card">
                            <i class="fas fa-plus-circle"></i>
                            <span>Add New Course</span>
                        </a>
                        <a href="results/add.php" class="action-card">
                            <i class="fas fa-plus"></i>
                            <span>Add New Result</span>
                        </a>
                        <a href="reports/student_performance.php" class="action-card">
                            <i class="fas fa-file-export"></i>
                            <span>Generate Report</span>
                        </a>
                    </div>
                </div>

                <!-- Recent Activity -->
                <div class="recent-activity">
                    <h2>Recent Activity</h2>
                    <div class="activity-table">
                        <table>
                            <thead>
                                <tr>
                                    <th>Activity</th>
                                    <th>Details</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                // Fetch recent activities (last 5)
                                $query = "SELECT * FROM (
                    SELECT 'Result Added' as activity, 
                           CONCAT(s.fname, ' ', s.lname, ' - ', r.course_code) as details,
                           r.created_at as date
                    FROM results r
                    JOIN students s ON r.student_id = s.id
                    ORDER BY r.created_at DESC
                    LIMIT 5
                ) as recent_activities
                ORDER BY date DESC";

                                $activities = $conn->query($query);

                                while ($activity = $activities->fetch_assoc()): ?>
                                    <tr>
                                        <td>
                                            <span class="activity-type">
                                                <i class="fas fa-plus-circle"></i>
                                                <?php echo htmlspecialchars($activity['activity']); ?>
                                            </span>
                                        </td>
                                        <td><?php echo htmlspecialchars($activity['details']); ?></td>
                                        <td><?php echo date('M d, Y H:i', strtotime($activity['date'])); ?></td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
        </main>
    </div>

    <script src="../../assets/js/admin_dashboard.js"></script>
</body>

</html>