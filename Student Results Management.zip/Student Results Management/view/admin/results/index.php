<?php
session_start();
require_once '../../../db/config.php';

// Check if user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../../login.php");
    exit();
}

// Pagination
$limit = 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// Search and Filter functionality
$search = isset($_GET['search']) ? $_GET['search'] : '';
$semester = isset($_GET['semester']) ? $_GET['semester'] : '';
$program = isset($_GET['program']) ? $_GET['program'] : '';

// Build query conditions
$conditions = [];
$params = [];
$types = '';

if ($search) {
    $conditions[] = "(s.student_id LIKE ? OR s.fname LIKE ? OR s.lname LIKE ? OR r.course_code LIKE ?)";
    $searchTerm = "%$search%";
    $params = array_merge($params, [$searchTerm, $searchTerm, $searchTerm, $searchTerm]);
    $types .= 'ssss';
}

if ($semester) {
    $conditions[] = "r.semester = ?";
    $params[] = $semester;
    $types .= 'i';
}

if ($program) {
    $conditions[] = "s.program = ?";
    $params[] = $program;
    $types .= 's';
}

$whereClause = !empty($conditions) ? 'WHERE ' . implode(' AND ', $conditions) : '';

// Get total number of results
$countQuery = "SELECT COUNT(*) as total FROM results r 
               JOIN students s ON r.student_id = s.id 
               JOIN courses c ON r.course_code = c.course_code 
               $whereClause";

$countStmt = $conn->prepare($countQuery);
if (!empty($params)) {
    $countStmt->bind_param($types, ...$params);
}
$countStmt->execute();
$totalResults = $countStmt->get_result()->fetch_assoc()['total'];
$totalPages = ceil($totalResults / $limit);

// Get results for current page
$query = "SELECT r.*, s.student_id as student_number, s.fname, s.lname, 
          c.course_name, c.credit_hours 
          FROM results r 
          JOIN students s ON r.student_id = s.id 
          JOIN courses c ON r.course_code = c.course_code 
          $whereClause 
          ORDER BY r.created_at DESC 
          LIMIT ? OFFSET ?";

$params[] = $limit;
$params[] = $offset;
$types .= 'ii';

$stmt = $conn->prepare($query);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$results = $stmt->get_result();

// Get unique programs for filter
$programs = $conn->query("SELECT DISTINCT program FROM students ORDER BY program")->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Results - SRMS Admin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../../../assets/css/admin_dashboard.css">
    <link rel="stylesheet" href="../../../assets/css/results_manage.css">
</head>
<body>
    <div class="admin-container">
        <!-- Include Sidebar -->
        <?php include_once '../includes/sidebar.php'; ?>

        <main class="main-content">
            <div class="header">
                <h1>Manage Results</h1>
                <a href="add.php" class="btn-add">
                    <i class="fas fa-plus"></i> Add New Result
                </a>
            </div>

            <!-- Search and Filter Section -->
            <div class="filters-section">
                <form action="" method="GET" class="filters-form">
                    <div class="search-group">
                        <input type="text" name="search" 
                               placeholder="Search by student ID, name, or course..."
                               value="<?php echo htmlspecialchars($search); ?>">
                    </div>

                    <div class="filter-group">
                        <select name="semester">
                            <option value="">All Semesters</option>
                            <?php for($i = 1; $i <= 8; $i++): ?>
                                <option value="<?php echo $i; ?>" 
                                    <?php echo $semester == $i ? 'selected' : ''; ?>>
                                    Semester <?php echo $i; ?>
                                </option>
                            <?php endfor; ?>
                        </select>
                    </div>

                    <div class="filter-group">
                        <select name="program">
                            <option value="">All Programs</option>
                            <?php foreach($programs as $prog): ?>
                                <option value="<?php echo htmlspecialchars($prog['program']); ?>"
                                    <?php echo $program == $prog['program'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($prog['program']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <button type="submit" class="btn-filter">
                        <i class="fas fa-search"></i> Search
                    </button>
                    
                    <?php if($search || $semester || $program): ?>
                        <a href="index.php" class="btn-clear">Clear Filters</a>
                    <?php endif; ?>
                </form>
            </div>

            <!-- Results Table -->
            <div class="table-container">
                <?php if ($results->num_rows > 0): ?>
                    <table>
                        <thead>
                            <tr>
                                <th>Student ID</th>
                                <th>Student Name</th>
                                <th>Course Code</th>
                                <th>Course Name</th>
                                <th>Credits</th>
                                <th>Grade</th>
                                <th>Semester</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($result = $results->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($result['student_number']); ?></td>
                                    <td>
                                        <?php echo htmlspecialchars($result['fname'] . ' ' . $result['lname']); ?>
                                    </td>
                                    <td><?php echo htmlspecialchars($result['course_code']); ?></td>
                                    <td><?php echo htmlspecialchars($result['course_name']); ?></td>
                                    <td><?php echo htmlspecialchars($result['credit_hours']); ?></td>
                                    <td>
                                        <span class="grade-badge grade-<?php echo strtolower($result['grade']); ?>">
                                            <?php echo htmlspecialchars($result['grade']); ?>
                                        </span>
                                    </td>
                                    <td><?php echo htmlspecialchars($result['semester']); ?></td>
                                    <td class="actions">
                                        <a href="edit.php?id=<?php echo $result['id']; ?>" 
                                           class="btn-edit" title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <button onclick="deleteResult(<?php echo $result['id']; ?>)" 
                                                class="btn-delete" title="Delete">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>

                    <!-- Pagination -->
                    <?php if ($totalPages > 1): ?>
                        <div class="pagination">
                            <?php if ($page > 1): ?>
                                <a href="?page=<?php echo ($page-1); ?>&search=<?php echo urlencode($search); ?>&semester=<?php echo $semester; ?>&program=<?php echo urlencode($program); ?>" class="page-link">
                                    <i class="fas fa-chevron-left"></i> Previous
                                </a>
                            <?php endif; ?>
                            
                            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                                <a href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>&semester=<?php echo $semester; ?>&program=<?php echo urlencode($program); ?>" 
                                   class="page-link <?php echo $i === $page ? 'active' : ''; ?>">
                                    <?php echo $i; ?>
                                </a>
                            <?php endfor; ?>
                            
                            <?php if ($page < $totalPages): ?>
                                <a href="?page=<?php echo ($page+1); ?>&search=<?php echo urlencode($search); ?>&semester=<?php echo $semester; ?>&program=<?php echo urlencode($program); ?>" class="page-link">
                                    Next <i class="fas fa-chevron-right"></i>
                                </a>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                <?php else: ?>
                    <div class="no-records">
                        <i class="fas fa-clipboard-list"></i>
                        <p>No results found</p>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>

    <!-- Delete Confirmation Modal -->
    <div id="deleteModal" class="modal">
        <div class="modal-content">
            <h2>Confirm Deletion</h2>
            <p>Are you sure you want to delete this result? This action cannot be undone.</p>
            <div class="modal-actions">
                <button onclick="confirmDelete()" class="btn-confirm">Yes, Delete</button>
                <button onclick="closeModal()" class="btn-cancel">Cancel</button>
            </div>
        </div>
    </div>

    <script>
        let resultToDelete = null;

        function deleteResult(resultId) {
            resultToDelete = resultId;
            document.getElementById('deleteModal').style.display = 'flex';
        }

        function closeModal() {
            document.getElementById('deleteModal').style.display = 'none';
        }

        function confirmDelete() {
            if (resultToDelete) {
                window.location.href = `../../../actions/results/delete.php?id=${resultToDelete}`;
            }
        }

        // Close modal when clicking outside
        window.onclick = function(event) {
            const modal = document.getElementById('deleteModal');
            if (event.target == modal) {
                closeModal();
            }
        }
    </script>
</body>
</html>