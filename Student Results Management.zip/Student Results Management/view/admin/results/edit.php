<?php
session_start();
require_once '../../../db/config.php';

// Check if user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../../login.php");
    exit();
}

// Check if result ID is provided
if (!isset($_GET['id'])) {
    $_SESSION['error'] = "No result selected for editing";
    header("Location: index.php");
    exit();
}

// Fetch the result details
$result_id = $_GET['id'];
$stmt = $conn->prepare("
    SELECT r.*, s.student_id as student_number, s.fname, s.lname, 
           c.course_name, c.credit_hours 
    FROM results r
    JOIN students s ON r.student_id = s.id
    JOIN courses c ON r.course_code = c.course_code
    WHERE r.id = ?
");
$stmt->bind_param("i", $result_id);
$stmt->execute();
$result = $stmt->get_result()->fetch_assoc();

if (!$result) {
    $_SESSION['error'] = "Result not found";
    header("Location: index.php");
    exit();
}

// Get all available grades
$grades = ['A+', 'A', 'B+', 'B', 'C+', 'C', 'D', 'E', 'F'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Result - SRMS Admin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../../../assets/css/admin_dashboard.css">
    <link rel="stylesheet" href="../../../assets/css/results_manage.css">
    <link rel="stylesheet" href="../../../assets/css/edit_result.css">
</head>
<body>
    <div class="admin-container">
        <!-- Include Sidebar -->
        <?php include_once '../includes/sidebar.php'; ?>

        <main class="main-content">
            <div class="page-header">
                <h1>Edit Result</h1>
                <a href="index.php" class="back-button">
                    <i class="fas fa-arrow-left"></i> Back to Results
                </a>
            </div>

            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert error">
                    <?php 
                        echo $_SESSION['error']; 
                        unset($_SESSION['error']);
                    ?>
                </div>
            <?php endif; ?>

            <?php if (isset($_SESSION['success'])): ?>
                <div class="alert success">
                    <?php 
                        echo $_SESSION['success']; 
                        unset($_SESSION['success']);
                    ?>
                </div>
            <?php endif; ?>

            <div class="form-container">
                <form action="../../../actions/results/update_result.php" method="POST" id="editResultForm">
                    <input type="hidden" name="result_id" value="<?php echo $result_id; ?>">

                    <!-- Student Information (Read-only) -->
                    <div class="form-section">
                        <h2>Student Information</h2>
                        <div class="info-group">
                            <label>Student ID</label>
                            <input type="text" value="<?php echo htmlspecialchars($result['student_number']); ?>" readonly>
                        </div>
                        <div class="info-group">
                            <label>Student Name</label>
                            <input type="text" value="<?php echo htmlspecialchars($result['fname'] . ' ' . $result['lname']); ?>" readonly>
                        </div>
                    </div>

                    <!-- Course Information (Read-only) -->
                    <div class="form-section">
                        <h2>Course Information</h2>
                        <div class="info-group">
                            <label>Course Code</label>
                            <input type="text" value="<?php echo htmlspecialchars($result['course_code']); ?>" readonly>
                        </div>
                        <div class="info-group">
                            <label>Course Name</label>
                            <input type="text" value="<?php echo htmlspecialchars($result['course_name']); ?>" readonly>
                        </div>
                        <div class="info-group">
                            <label>Credit Hours</label>
                            <input type="text" value="<?php echo htmlspecialchars($result['credit_hours']); ?>" readonly>
                        </div>
                    </div>

                    <!-- Grade Information (Editable) -->
                    <div class="form-section">
                        <h2>Grade Information</h2>
                        <div class="form-group">
                            <label for="grade">Grade *</label>
                            <select name="grade" id="grade" required>
                                <?php foreach ($grades as $grade): ?>
                                    <option value="<?php echo $grade; ?>" 
                                        <?php echo $result['grade'] === $grade ? 'selected' : ''; ?>>
                                        <?php echo $grade; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <small class="error-message"></small>
                        </div>

                        <div class="form-group">
                            <label for="exam_date">Exam Date *</label>
                            <input type="date" id="exam_date" name="exam_date" 
                                   value="<?php echo htmlspecialchars($result['exam_date']); ?>" required>
                            <small class="error-message"></small>
                        </div>
                    </div>

                    <div class="form-actions">
                        <button type="submit" class="btn-submit">
                            <i class="fas fa-save"></i> Save Changes
                        </button>
                        <a href="index.php" class="btn-cancel">
                            <i class="fas fa-times"></i> Cancel
                        </a>
                    </div>
                </form>
            </div>
        </main>
    </div>

    <script>
        document.getElementById('editResultForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Basic validation
            let isValid = true;
            const requiredFields = ['grade', 'exam_date'];
            
            requiredFields.forEach(field => {
                const element = document.getElementById(field);
                const formGroup = element.closest('.form-group');
                const errorDisplay = formGroup.querySelector('.error-message');
                
                if (!element.value.trim()) {
                    formGroup.classList.add('error');
                    errorDisplay.textContent = 'This field is required';
                    isValid = false;
                } else {
                    formGroup.classList.remove('error');
                    errorDisplay.textContent = '';
                }
            });

            if (isValid) {
                const submitBtn = document.querySelector('.btn-submit');
                submitBtn.disabled = true;
                submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';
                this.submit();
            }
        });
    </script>
</body>
</html>