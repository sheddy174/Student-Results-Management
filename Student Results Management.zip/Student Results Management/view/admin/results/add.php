<?php
session_start();
require_once '../../../db/config.php';

// Check if user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../../login.php");
    exit();
}

// Fetch all students
$students = $conn->query("SELECT id, student_id, fname, lname FROM students ORDER BY fname, lname");

// Fetch all courses
$courses = $conn->query("SELECT course_code, course_name, credit_hours FROM courses ORDER BY course_code"); 

// Get available semesters (1-8 for 4 years)
$semesters = range(1, 8);

// Define possible grades
$grades = ['A+', 'A', 'B+', 'B', 'C+', 'C', 'D', 'E', 'F'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Result - SRMS Admin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../../../assets/css/admin_dashboard.css">
    <link rel="stylesheet" href="../../../assets/css/results_manage.css">
    <link rel="stylesheet" href="../../../assets/css/add_result.css">
</head>
<body>
    <div class="admin-container">
        <!-- Include Sidebar -->
        <?php include_once '../includes/sidebar.php'; ?>

        <main class="main-content">
            <div class="page-header">
                <h1>Add New Result</h1>
                <a href="index.php" class="back-button">
                    <i class="fas fa-arrow-left"></i> Back to Results
                </a>
            </div>

            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert error">
                    <?php 
                        echo $_SESSION['error']; 
                        unset($_SESSION['error']);
                    ?>
                </div>
            <?php endif; ?>

            <?php if (isset($_SESSION['success'])): ?>
                <div class="alert success">
                    <?php 
                        echo $_SESSION['success']; 
                        unset($_SESSION['success']);
                    ?>
                </div>
            <?php endif; ?>

            <div class="form-container">
                <form action="../../../actions/results/add_result.php" method="POST" id="addResultForm">
                    <!-- Student Selection -->
                    <div class="form-section">
                        <h2>Student Information</h2>
                        <div class="form-group">
                            <label for="student_id">Select Student *</label>
                            <select name="student_id" id="student_id" required>
                                <option value="">Select a student</option>
                                <?php while ($student = $students->fetch_assoc()): ?>
                                    <option value="<?php echo $student['id']; ?>">
                                        <?php echo htmlspecialchars($student['student_id'] . ' - ' . 
                                                                  $student['fname'] . ' ' . 
                                                                  $student['lname']); ?>
                                    </option>
                                <?php endwhile; ?>
                            </select>
                            <small class="error-message"></small>
                        </div>
                    </div>

                    <!-- Course Selection -->
                    <div class="form-section">
                        <h2>Course Information</h2>
                        <div class="form-group">
                            <label for="course_code">Select Course *</label>
                            <select name="course_code" id="course_code" required>
                                <option value="">Select a course</option>
                                <?php while ($course = $courses->fetch_assoc()): ?>
                                    <option value="<?php echo $course['course_code']; ?>" 
                                            data-credits="<?php echo $course['credit_hours']; ?>">
                                        <?php echo htmlspecialchars($course['course_code'] . ' - ' . 
                                                                  $course['course_name'] . 
                                                                  ' (' . $course['credit_hours'] . ' credits)'); ?>
                                    </option>
                                <?php endwhile; ?>
                            </select>
                            <small class="error-message"></small>
                        </div>

                        <div class="form-group">
                            <label for="semester">Select Semester *</label>
                            <select name="semester" id="semester" required>
                                <option value="">Select semester</option>
                                <?php foreach ($semesters as $semester): ?>
                                    <option value="<?php echo $semester; ?>">
                                        Semester <?php echo $semester; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <small class="error-message"></small>
                        </div>
                    </div>

                    <!-- Grade Information -->
                    <div class="form-section">
                        <h2>Grade Information</h2>
                        <div class="form-group">
                            <label for="grade">Select Grade *</label>
                            <select name="grade" id="grade" required>
                                <option value="">Select grade</option>
                                <?php foreach ($grades as $grade): ?>
                                    <option value="<?php echo $grade; ?>">
                                        <?php echo $grade; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <small class="error-message"></small>
                        </div>

                        <div class="form-group">
                            <label for="exam_date">Exam Date *</label>
                            <!-- <input type="date" id="exam_date" name="exam_date" required> -->
                            <input type="date" id="exam_date" name="exam_date" required 
                            min="2000-01-01" max="2030-12-31">
                            <small class="error-message"></small>
                        </div>
                    </div>

                    <div class="form-actions">
                        <button type="submit" class="btn-submit">
                            <i class="fas fa-plus"></i> Add Result
                        </button>
                        <button type="reset" class="btn-reset">
                            <i class="fas fa-undo"></i> Reset Form
                        </button>
                    </div>
                </form>
            </div>
        </main>
    </div>

    <script>
        document.getElementById('addResultForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Basic validation
            let isValid = true;
            const requiredFields = ['student_id', 'course_code', 'semester', 'grade', 'exam_date'];
            
            requiredFields.forEach(field => {
                const element = document.getElementById(field);
                const formGroup = element.closest('.form-group');
                const errorDisplay = formGroup.querySelector('.error-message');
                
                if (!element.value.trim()) {
                    formGroup.classList.add('error');
                    errorDisplay.textContent = 'This field is required';
                    isValid = false;
                } else {
                    formGroup.classList.remove('error');
                    errorDisplay.textContent = '';
                }
            });

            if (isValid) {
                const submitBtn = document.querySelector('.btn-submit');
                submitBtn.disabled = true;
                submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Adding...';
                this.submit();
            }
        });

        // Reset form handler
        document.querySelector('.btn-reset').addEventListener('click', function() {
            const formGroups = document.querySelectorAll('.form-group');
            formGroups.forEach(group => {
                group.classList.remove('error');
                const errorDisplay = group.querySelector('.error-message');
                if (errorDisplay) {
                    errorDisplay.textContent = '';
                }
            });
        });
    </script>
</body>
</html>