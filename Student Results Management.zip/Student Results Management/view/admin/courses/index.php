<?php
session_start();
require_once '../../../db/config.php';

// Check if user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../../login.php");
    exit();
}

// Pagination
$limit = 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// Search functionality
$search = isset($_GET['search']) ? $_GET['search'] : '';
$whereClause = '';
$params = [];
$types = '';

if ($search) {
    $whereClause = "WHERE course_code LIKE ? OR course_name LIKE ?";
    $searchTerm = "%$search%";
    $params = [$searchTerm, $searchTerm];
    $types = 'ss';
}

// Get total number of courses
$countQuery = "SELECT COUNT(*) as total FROM courses $whereClause";
if (!empty($params)) {
    $stmt = $conn->prepare($countQuery);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $totalCourses = $stmt->get_result()->fetch_assoc()['total'];
} else {
    $totalCourses = $conn->query($countQuery)->fetch_assoc()['total'];
}

$totalPages = ceil($totalCourses / $limit);

// Get courses for current page
$query = "SELECT * FROM courses $whereClause ORDER BY course_code LIMIT ? OFFSET ?";
$params[] = $limit;
$params[] = $offset;
$types .= 'ii';

$stmt = $conn->prepare($query);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$courses = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Courses - SRMS Admin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../../../assets/css/admin_dashboard.css">
    <link rel="stylesheet" href="../../../assets/css/courses_manage.css">
</head>
<body>
    <div class="admin-container">
        <!-- Include Sidebar -->
        <?php include_once '../includes/sidebar.php'; ?>

        <main class="main-content">
            <div class="header">
                <h1>Manage Courses</h1>
                <a href="add.php" class="btn-add">
                    <i class="fas fa-plus"></i> Add New Course
                </a>
            </div>

            <!-- Display Messages -->
            <?php if (isset($_SESSION['success'])): ?>
                <div class="alert success">
                    <?php 
                        echo $_SESSION['success']; 
                        unset($_SESSION['success']);
                    ?>
                </div>
            <?php endif; ?>

            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert error">
                    <?php 
                        echo $_SESSION['error']; 
                        unset($_SESSION['error']);
                    ?>
                </div>
            <?php endif; ?>

            <!-- Search Section -->
            <div class="search-section">
                <form action="" method="GET" class="search-form">
                    <div class="search-input">
                        <input type="text" name="search" 
                               placeholder="Search by course code or name..."
                               value="<?php echo htmlspecialchars($search); ?>">
                        <button type="submit">
                            <i class="fas fa-search"></i>
                        </button>
                    </div>
                </form>
            </div>

            <!-- Courses Table -->
            <div class="table-container">
                <?php if ($courses->num_rows > 0): ?>
                    <table>
                        <thead>
                            <tr>
                                <th>Course Code</th>
                                <th>Course Name</th>
                                <th>Credit Hours</th>
                                <th>Department</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($course = $courses->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($course['course_code']); ?></td>
                                    <td><?php echo htmlspecialchars($course['course_name']); ?></td>
                                    <td><?php echo htmlspecialchars($course['credit_hours']); ?></td>
                                    <td><?php echo htmlspecialchars($course['department_id']); ?></td>
                                    <td class="actions">
                                    <a href="edit.php?code=<?php echo $course['course_code']; ?>" class="btn-edit" title="Edit">
                                        <!-- <a href="edit.php?id=< //?php echo $course['id']; ?>"  -->
                                           
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <button onclick="deleteCourse('<?php echo $course['course_code']; ?>')" 
                                                class="btn-delete" title="Delete">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>

                    <!-- Pagination -->
                    <?php if ($totalPages > 1): ?>
                        <div class="pagination">
                            <?php if ($page > 1): ?>
                                <a href="?page=<?php echo ($page-1); ?>&search=<?php echo urlencode($search); ?>" 
                                   class="page-link">
                                    <i class="fas fa-chevron-left"></i> Previous
                                </a>
                            <?php endif; ?>
                            
                            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                                <a href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>" 
                                   class="page-link <?php echo $i === $page ? 'active' : ''; ?>">
                                    <?php echo $i; ?>
                                </a>
                            <?php endfor; ?>
                            
                            <?php if ($page < $totalPages): ?>
                                <a href="?page=<?php echo ($page+1); ?>&search=<?php echo urlencode($search); ?>" 
                                   class="page-link">
                                    Next <i class="fas fa-chevron-right"></i>
                                </a>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                <?php else: ?>
                    <div class="no-records">
                        <i class="fas fa-book"></i>
                        <p>No courses found</p>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>

    <!-- Delete Confirmation Modal -->
    <div id="deleteModal" class="modal">
        <div class="modal-content">
            <h2>Confirm Deletion</h2>
            <p>Are you sure you want to delete this course? This action cannot be undone.</p>
            <p class="warning">Note: Deleting a course will also remove all associated results.</p>
            <div class="modal-actions">
                <button onclick="confirmDelete()" class="btn-confirm">Yes, Delete</button>
                <button onclick="closeModal()" class="btn-cancel">Cancel</button>
            </div>
        </div>
    </div>

    <script>
        let courseToDelete = null;

        function deleteCourse(courseCode) {
            courseToDelete = courseCode;
            document.getElementById('deleteModal').style.display = 'flex';
        }

        function closeModal() {
            document.getElementById('deleteModal').style.display = 'none';
        }

        function confirmDelete() {
            if (courseToDelete) {
                window.location.href = `../../../actions/courses/delete.php?code=${encodeURIComponent(courseToDelete)}`;
            }
        }

        // Close modal when clicking outside
        window.onclick = function(event) {
            const modal = document.getElementById('deleteModal');
            if (event.target == modal) {
                closeModal();
            }
        }
    </script>
</body>
</html>