<?php
session_start();
require_once '../../../db/config.php';

// Check if user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../../login.php");
    exit();
}

// Check if course code is provided
if (!isset($_GET['code'])) {
    $_SESSION['error'] = "No course selected for editing";
    header("Location: index.php");
    exit();
}

// Fetch course details
$course_code = $_GET['code'];
$stmt = $conn->prepare("SELECT * FROM courses WHERE course_code = ?");
$stmt->bind_param("s", $course_code);
$stmt->execute();
$course = $stmt->get_result()->fetch_assoc();

if (!$course) {
    $_SESSION['error'] = "Course not found";
    header("Location: index.php");
    exit();
}

// Fetch all departments for the dropdown
$departments = $conn->query("SELECT DISTINCT department_id, department_name FROM admins ORDER BY department_name");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Course - SRMS Admin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../../../assets/css/admin_dashboard.css">
    <link rel="stylesheet" href="../../../assets/css/courses_manage.css">
    <link rel="stylesheet" href="../../../assets/css/edit_course.css">

</head>
<body>
    <div class="admin-container">
        <!-- Include Sidebar -->
        <?php include_once '../includes/sidebar.php'; ?>

        <main class="main-content">
            <div class="page-header">
                <h1>Edit Course</h1>
                <a href="index.php" class="back-button">
                    <i class="fas fa-arrow-left"></i> Back to Courses
                </a>
            </div>

            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert error">
                    <?php 
                        echo $_SESSION['error']; 
                        unset($_SESSION['error']);
                    ?>
                </div>
            <?php endif; ?>

            <div class="form-container">
                <form action="../../../actions/courses/update_course.php" method="POST" id="editCourseForm">
                    <input type="hidden" name="original_code" value="<?php echo htmlspecialchars($course_code); ?>">
                    
                    <div class="form-section">
                        <h2>Course Information</h2>
                        
                        <div class="form-group">
                            <label for="course_code">Course Code *</label>
                            <input type="text" id="course_code" name="course_code" 
                                   value="<?php echo htmlspecialchars($course['course_code']); ?>" required>
                            <small class="helper-text">Enter a unique course code</small>
                            <small class="error-message"></small>
                        </div>

                        <div class="form-group">
                            <label for="course_name">Course Name *</label>
                            <input type="text" id="course_name" name="course_name" 
                                   value="<?php echo htmlspecialchars($course['course_name']); ?>" required>
                            <small class="error-message"></small>
                        </div>

                        <div class="form-group">
                            <label for="department_id">Department *</label>
                            <select id="department_id" name="department_id" required>
                                <option value="">Select Department</option>
                                <?php while ($dept = $departments->fetch_assoc()): ?>
                                    <option value="<?php echo htmlspecialchars($dept['department_id']); ?>"
                                            <?php echo $dept['department_id'] === $course['department_id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($dept['department_name']); ?>
                                    </option>
                                <?php endwhile; ?>
                            </select>
                            <small class="error-message"></small>
                        </div>

                        <div class="form-group">
                            <label for="credit_hours">Credit Hours *</label>
                            <input type="number" id="credit_hours" name="credit_hours" 
                                   value="<?php echo htmlspecialchars($course['credit_hours']); ?>"
                                   min="1" max="6" required>
                            <small class="helper-text">Enter a value between 1 and 6</small>
                            <small class="error-message"></small>
                        </div>

                        <div class="form-group">
                            <label for="description">Course Description</label>
                            <textarea id="description" name="description" rows="4"><?php echo htmlspecialchars($course['description'] ?? ''); ?></textarea>
                            <small class="error-message"></small>
                        </div>
                    </div>

                    <div class="form-actions">
                        <button type="submit" class="btn-submit">
                            <i class="fas fa-save"></i> Save Changes
                        </button>
                        <a href="index.php" class="btn-cancel">
                            <i class="fas fa-times"></i> Cancel
                        </a>
                    </div>
                </form>
            </div>
        </main>
    </div>

    <script>
        document.getElementById('editCourseForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            let isValid = true;
            const courseCode = document.getElementById('course_code');
            const courseName = document.getElementById('course_name');
            const creditHours = document.getElementById('credit_hours');
            
            // Course code validation
            const codePattern = /^[A-Z0-9-]{2,10}$/;
            if (!codePattern.test(courseCode.value.trim())) {
                setError(courseCode, 'Course code should be 2-10 characters, using only uppercase letters, numbers, and dashes');
                isValid = false;
            } else {
                setSuccess(courseCode);
            }

            // Course name validation
            if (courseName.value.trim().length < 3) {
                setError(courseName, 'Course name must be at least 3 characters long');
                isValid = false;
            } else {
                setSuccess(courseName);
            }

            // Credit hours validation
            const credits = parseInt(creditHours.value);
            if (isNaN(credits) || credits < 1 || credits > 6) {
                setError(creditHours, 'Credit hours must be between 1 and 6');
                isValid = false;
            } else {
                setSuccess(creditHours);
            }

            if (isValid) {
                const submitBtn = document.querySelector('.btn-submit');
                submitBtn.disabled = true;
                submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';
                this.submit();
            }
        });

        function setError(element, message) {
            const formGroup = element.parentElement;
            const errorDisplay = formGroup.querySelector('.error-message');
            formGroup.classList.add('error');
            errorDisplay.textContent = message;
        }

        function setSuccess(element) {
            const formGroup = element.parentElement;
            formGroup.classList.remove('error');
            const errorDisplay = formGroup.querySelector('.error-message');
            errorDisplay.textContent = '';
        }
    </script>
</body>
</html>