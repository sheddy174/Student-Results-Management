<?php
session_start();
require_once '../../../db/config.php';

// Check if user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../../login.php");
    exit();
}

// Fetch all students for the dropdown
$students_query = $conn->query("SELECT id, fname, lname, student_id FROM students ORDER BY lname, fname");

// Process report generation if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['student_id'])) {
    // Fetch student details
    $student_id = $conn->real_escape_string($_POST['student_id']);
    $student_query = $conn->query("SELECT * FROM students WHERE id = '$student_id'");
    $student = $student_query->fetch_assoc();

    // Fetch student results with course details and actual credit hours
    $results_query = $conn->query("
        SELECT 
            r.course_code, 
            r.course_name, 
            r.grade, 
            r.semester, 
            r.academic_year,
            r.exam_date,
            c.credit_hours
        FROM results r
        LEFT JOIN courses c ON r.course_code = c.course_code
        WHERE r.student_id = '$student_id'
        ORDER BY r.academic_year, r.semester
    ");

    // Prepare results array
    $results = [];

    // Calculate overall GPA
    $totalCredits = 0;
    $totalWeightedPoints = 0;
    $gradePointMap = [
        'A+' => 4.00,
        'A'  => 4.00,
        'B+' => 3.50,
        'B'  => 3.00,
        'C+' => 2.50,
        'C'  => 2.00,
        'D'  => 1.00,
        'E'  => 0.50,
        'F'  => 0.00
    ];

    // Process results and calculate GPA
    while ($row = $results_query->fetch_assoc()) {
        // Use actual course credit hours, default to 3 if not found
        $creditHours = $row['credit_hours'] ?? 3;

        // Calculate grade points
        $gradePoint = $gradePointMap[$row['grade']] ?? 0;
        $gradePointEarned = $gradePoint * $creditHours;

        $row['credit_hours'] = $creditHours;
        $row['grade_point_earned'] = $gradePointEarned;

        $results[] = $row;

        $totalCredits += $creditHours;
        $totalWeightedPoints += $gradePointEarned;
    }

    // Calculate overall GPA
    $overallGPA = $totalCredits > 0 ? round($totalWeightedPoints / $totalCredits, 2) : 0;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Performance Report - SRMS Admin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../../../assets/css/admin_dashboard.css">
    <link rel="stylesheet" href="../../../assets/css/reports_manage.css">
    <link rel="stylesheet" href="../../../assets/css/student_performance.css">
</head>

<body>
    <div class="admin-container">
        <!-- Include Sidebar -->
        <?php include_once '../includes/sidebar.php'; ?>

        <main class="main-content p-6">
            <div class="page-header">
                <h1 class="text-2xl font-bold text-gray-800">Student Performance Report</h1>
            </div>


            <div class="student-info-header">
                <!-- <h2>Performance Report</h2> -->
                <a href="index.php" class="back-button">
                    <i class="fas fa-arrow-left"></i> Back to Results
                </a>
            </div>

            <!-- Report Generation Form -->
            <div class="bg-white shadow-md rounded-lg p-6 mb-6">
                <form method="POST" class="space-y-4">
                    <div>
                        <label for="student_id" class="block text-sm font-medium text-gray-700">Select Student</label>
                        <select
                            name="student_id"
                            id="student_id"
                            required
                            class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50">
                            <option value="">Select a student</option>
                            <?php while ($student_option = $students_query->fetch_assoc()): ?>
                                <option value="<?= htmlspecialchars($student_option['id']) ?>">
                                    <?= htmlspecialchars($student_option['fname'] . ' ' . $student_option['lname'] . ' (' . $student_option['student_id'] . ')') ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>

                    <button
                        type="submit"
                        class="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition duration-300">
                        Generate Report
                    </button>
                </form>
            </div>

            <!-- Report Display -->
            <?php if (isset($student) && isset($results) && !empty($results)): ?>
                <div class="bg-white shadow-md rounded-lg p-6">
                    <div class="mb-6">
                        <h2 class="text-xl font-semibold text-gray-800 mb-2">
                            Performance Report for <?= htmlspecialchars($student['fname'] . ' ' . $student['lname']) ?>
                        </h2>
                        <p class="text-gray-600">
                            Student ID: <?= htmlspecialchars($student['student_id']) ?> |
                            Program: <?= htmlspecialchars($student['program']) ?> |
                            Year: <?= htmlspecialchars($student['year']) ?>
                        </p>
                    </div>

                    <div class="overflow-x-auto">
                        <table class="w-full border-collapse">
                            <thead>
                                <tr class="bg-gray-100">
                                    <th class="border p-2 text-left">Course Code</th>
                                    <th class="border p-2 text-left">Course Name</th>
                                    <th class="border p-2 text-center">Semester</th>
                                    <th class="border p-2 text-center">Academic Year</th>
                                    <th class="border p-2 text-center">Grade</th>
                                    <th class="border p-2 text-center">Credits</th>
                                    <th class="border p-2 text-center">Exam Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($results as $result): ?>
                                    <tr>
                                        <td class="border p-2"><?= htmlspecialchars($result['course_code']) ?></td>
                                        <td class="border p-2"><?= htmlspecialchars($result['course_name']) ?></td>
                                        <td class="border p-2 text-center"><?= htmlspecialchars($result['semester']) ?></td>
                                        <td class="border p-2 text-center"><?= htmlspecialchars($result['academic_year'] ?: 'N/A') ?></td>
                                        <td class="border p-2 text-center"><?= htmlspecialchars($result['grade']) ?></td>
                                        <td class="border p-2 text-center"><?= htmlspecialchars($result['credit_hours']) ?></td>
                                        <td class="border p-2 text-center"><?= $result['exam_date'] ? htmlspecialchars($result['exam_date']) : 'N/A' ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="mt-6 bg-gray-100 p-4 rounded-md">
                        <h3 class="text-lg font-semibold mb-2">Performance Summary</h3>
                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <p class="text-gray-700">Overall GPA: <span class="font-bold"><?= $overallGPA ?></span></p>
                                <p class="text-gray-700">Total Courses: <span class="font-bold"><?= count($results) ?></span></p>
                            </div>
                            <div>
                                <p class="text-gray-700">Total Credits Attempted: <span class="font-bold"><?= $totalCredits ?></span></p>
                            </div>
                        </div>
                    </div>
                </div>
            <?php elseif (isset($_POST['student_id']) && (!isset($results) || empty($results))): ?>
                <div class="bg-yellow-100 border border-yellow-400 text-yellow-700 px-4 py-3 rounded relative" role="alert">
                    No results found for the selected student.
                </div>
            <?php endif; ?>
        </main>
    </div>
</body>

</html>