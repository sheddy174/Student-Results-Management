<?php
session_start();
require_once '../../../db/config.php';

// Check if user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../../login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Generate Reports - SRMS Admin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../../../assets/css/admin_dashboard.css">
    <link rel="stylesheet" href="../../../assets/css/reports_manage.css">
</head>
<body>
    <div class="admin-container">
        <!-- Include Sidebar -->
        <?php include_once '../includes/sidebar.php'; ?>

        <main class="main-content">
            <div class="page-header">
                <h1>Generate Reports</h1>
            </div>

            <div class="reports-grid">
                <!-- Student Performance Report -->
                <div class="report-card">
                    <div class="report-icon">
                        <i class="fas fa-user-graduate"></i>
                    </div>
                    <h3>Student Performance Report</h3>
                    <p>Generate detailed performance report for individual students</p>
                    <a href="student_performance.php" class="btn-generate">
                        Generate Report <i class="fas fa-arrow-right"></i>
                    </a>
                </div>

                <!-- Course Analysis Report -->
                <!-- <div class="report-card">
                    <div class="report-icon">
                        <i class="fas fa-book"></i>
                    </div>
                    <h3>Course Analysis Report</h3>
                    <p>View grade distribution and performance by course</p>
                    <a href="course_analysis.php" class="btn-generate">
                        Generate Report <i class="fas fa-arrow-right"></i>
                    </a>
                </div> -->

                <!-- Program Performance Report -->
                <!-- <div class="report-card">
                    <div class="report-icon">
                        <i class="fas fa-chart-bar"></i>
                    </div>
                    <h3>Program Performance Report</h3>
                    <p>Analyze performance trends across programs</p>
                    <a href="program_performance.php" class="btn-generate">
                        Generate Report <i class="fas fa-arrow-right"></i>
                    </a>
                </div> -->

                <!-- Grade Distribution Report -->
                <!-- <div class="report-card">
                    <div class="report-icon">
                        <i class="fas fa-chart-pie"></i>
                    </div>
                    <h3>Grade Distribution Report</h3>
                    <p>View overall grade distribution statistics</p>
                    <a href="grade_distribution.php" class="btn-generate">
                        Generate Report <i class="fas fa-arrow-right"></i>
                    </a>
                </div> -->
            </div>
        </main>
    </div>
</body>
</html>