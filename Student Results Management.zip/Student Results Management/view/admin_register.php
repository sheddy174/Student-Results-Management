<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Faculty/Admin Registration - SRMS</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/admin_register.css">
</head>
<body>
    <div class="container">
        <h2>Faculty/Admin Registration</h2>
        <form id="signup-form" action="../actions/admin_register.php" method="POST" onsubmit="return validateAdminForm()">
            <!-- Personal Information -->
            <div class="form-control">
                <input type="text" id="firstname" name="fname" placeholder="Enter your firstname" required>
                <i class="fas fa-check-circle"></i>
                <i class="fas fa-exclamation-circle"></i>
                <small></small>
            </div>

            <div class="form-control">
                <input type="text" id="lastname" name="lname" placeholder="Enter your lastname" required>
                <i class="fas fa-check-circle"></i>
                <i class="fas fa-exclamation-circle"></i>
                <small></small>
            </div>

            <div class="form-control">
                <input type="email" id="email" name="email" placeholder="Enter your email" required>
                <i class="fas fa-check-circle"></i>
                <i class="fas fa-exclamation-circle"></i>
                <small></small>
            </div>

            <!-- Department Information -->
            <div class="form-control">
                <input type="text" id="department_id" name="department_id" placeholder="Enter Department ID" required>
                <i class="fas fa-check-circle"></i>
                <i class="fas fa-exclamation-circle"></i>
                <small></small>
            </div>

            <div class="form-control">
                <input type="text" id="department_name" name="department_name" placeholder="Enter Department Name" required>
                <i class="fas fa-check-circle"></i>
                <i class="fas fa-exclamation-circle"></i>
                <small></small>
            </div>

            <div class="form-control">
                <input type="text" id="institution" name="institution" placeholder="Enter Institution Name" required>
                <i class="fas fa-check-circle"></i>
                <i class="fas fa-exclamation-circle"></i>
                <small></small>
            </div>

            <!-- Security Information -->
            <div class="form-control">
                <input type="password" id="password" name="password" placeholder="Create password" required>
                <i class="fas fa-check-circle"></i>
                <i class="fas fa-exclamation-circle"></i>
                <small></small>
            </div>

            <div class="form-control">
                <input type="password" id="confirm_password" name="confirm_password" placeholder="Confirm password" required>
                <i class="fas fa-check-circle"></i>
                <i class="fas fa-exclamation-circle"></i>
                <small></small>
            </div>

            <!-- <div class="form-control checkbox">
                <input type="checkbox" id="terms" required>
                <label for="terms">I accept all terms & conditions</label>
            </div> -->


            <div class="form-control checkbox">
                <input type="checkbox" id="terms" name="terms" required>
                <label for="terms">I accept all terms & conditions</label>
                <small></small>
            </div>

            <button type="submit" class="auth-btn" name="submitBtn" id="submitBtn">Register as Faculty/Admin</button>
        </form>
        <p class="login-link">Already have an account? <a href="../view/login.php">Login now</a></p>
    </div>

    <script src="../assets/js/admin_validation.js"></script>
</body>
</html>