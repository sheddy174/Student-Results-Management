<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login - SRMS</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link rel="stylesheet" href="../assets/css/login.css">
</head>

<body>
  <div class="container">
    <h2>Login to Your Account</h2>
    <div class="role-tabs">
      <button class="tab-btn active" data-role="student">Student</button>
      <button class="tab-btn" data-role="admin">Faculty/Admin</button>
    </div>

    <form id="login-form" action="../actions/login.php" method="POST">
      <input type="hidden" name="role" id="role" value="student">

      <div class="form-control">
        <i class="fas fa-envelope"></i>
        <input type="email" id="email" name="email" placeholder="Enter your email" required>
      </div>

      <div class="form-control">
        <i class="fas fa-lock"></i>
        <input type="password" id="password" name="password" placeholder="Enter your password" required>
        <i class="fas fa-eye toggle-password"></i>
      </div>
      <div class="options">
        <div class="remember-me">
          <input type="checkbox" id="remember" name="remember">
          <label for="remember">Remember me</label>
        </div>
        <a href="forgot_password.php" class="forgot-password">Forgot Password?</a>
      </div>

      <button type="submit" class="auth-btn" name="loginBtn">Login</button>
    </form>

    <p class="register-link">Don't have an account? <a href="register.php">Register now</a></p>
  </div>

  <script>
    // Tab switching functionality
    const tabs = document.querySelectorAll('.tab-btn');
    const roleInput = document.getElementById('role');

    tabs.forEach(tab => {
      tab.addEventListener('click', () => {
        // Remove active class from all tabs
        tabs.forEach(t => t.classList.remove('active'));
        // Add active class to clicked tab
        tab.classList.add('active');
        // Update hidden role input
        roleInput.value = tab.dataset.role;
      });
    });

    // Password visibility toggle
    const togglePassword = document.querySelector('.toggle-password');
    const passwordInput = document.getElementById('password');

    togglePassword.addEventListener('click', function() {
      const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
      passwordInput.setAttribute('type', type);
      this.classList.toggle('fa-eye');
      this.classList.toggle('fa-eye-slash');
    });
  </script>
</body>

</html>