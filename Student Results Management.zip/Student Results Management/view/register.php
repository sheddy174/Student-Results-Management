<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Choose Registration Type - SRMS</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/register.css">
</head>
<body>
    <div class="container">
        <h2>Choose Registration Type</h2>
        <div class="role-selection">
            <a href="student_register.php" class="role-card">
                <i class="fas fa-user-graduate"></i>
                <h3>Register as Student</h3>
                <p>Register to access your academic results and reports</p>
            </a>
            <a href="admin_register.php" class="role-card">
                <i class="fas fa-user-tie"></i>
                <h3>Register as Faculty/Admin</h3>
                <p>Register to manage student results and academic records</p>
            </a>
        </div>
        <p class="login-link">Already have an account? <a href="../view/login.php">Login now</a></p>
    </div>
</body>
</html>