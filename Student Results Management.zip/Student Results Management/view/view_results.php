<?php
session_start();
require_once '../db/config.php';


ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


// Check if user is logged in and is a student
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: ../login.php");
    exit();
}

// Fetch student information
$student_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT * FROM students WHERE id = ?");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$student = $stmt->get_result()->fetch_assoc();

// Get selected semester (if any)
$selected_semester = isset($_GET['semester']) ? $_GET['semester'] : null;
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Results - SRMS</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/student_results.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>

</head>

<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="container">
            <div class="logo">SRMS</div>
            <div class="nav-links">
                <a href="../view/student/dashboard.php">Dashboard</a>
                <a href="view_results.php" class="active">Results</a>
                <a href="../view/student/profile.php">Profile</a>
                <a href="../../actions/logout.php" class="logout-btn">Logout</a>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="container">
        <!-- Student Info Section -->
        <div class="student-info">
            <h1>Academic Results</h1>
            <div class="info-grid">
                <div class="info-item">
                    <span>Student Name:</span>
                    <strong><?php echo htmlspecialchars($student['fname'] . ' ' . $student['lname']); ?></strong>
                </div>
                <div class="info-item">
                    <span>Student ID:</span>
                    <strong><?php echo htmlspecialchars($student['student_id']); ?></strong>
                </div>
                <div class="info-item">
                    <span>Program:</span>
                    <strong><?php echo htmlspecialchars($student['program']); ?></strong>
                </div>
            </div>
        </div>

        <!-- Semester Selection -->
        <div class="semester-selection">
            <form action="" method="GET" class="semester-form">
                <select name="semester" onchange="this.form.submit()">
                    <option value="">All Semesters</option>
                    <?php
                    // Fetch available semesters for this student
                    $stmt = $conn->prepare("SELECT DISTINCT semester FROM results WHERE student_id = ? ORDER BY semester");
                    $stmt->bind_param("i", $student_id);
                    $stmt->execute();
                    $semesters = $stmt->get_result();

                    while ($sem = $semesters->fetch_assoc()) {
                        $selected = ($selected_semester == $sem['semester']) ? 'selected' : '';
                        echo "<option value='" . $sem['semester'] . "' $selected>Semester " . $sem['semester'] . "</option>";
                    }
                    ?>
                </select>
            </form>
        </div>

        <!-- Results Display -->
        <div class="results-section">
            <?php
            // Prepare the base query
            $query = "SELECT r.*, c.credit_hours 
                     FROM results r 
                     JOIN courses c ON r.course_code = c.course_code 
                     WHERE r.student_id = ?";

            if ($selected_semester) {
                $query .= " AND r.semester = ?";
                $stmt = $conn->prepare($query);
                $stmt->bind_param("ii", $student_id, $selected_semester);
            } else {
                $stmt = $conn->prepare($query);
                $stmt->bind_param("i", $student_id);
            }

            $stmt->execute();
            $results = $stmt->get_result();

            if ($results->num_rows > 0) {
                $total_credits = 0;
                $total_grade_points = 0;
            ?>
                <div class="results-table">
                    <table>
                        <thead>
                            <tr>
                                <th>Course Code</th>
                                <th>Course Name</th>
                                <th>Credit Hours</th>
                                <th>Grade</th>
                                <th>Grade Point</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            while ($result = $results->fetch_assoc()) {
                                // Calculate grade point based on grade
                                $grade_points = [
                                    'A+' => 4.0,
                                    'A' => 4.0,
                                    'A-' => 3.7,
                                    'B+' => 3.3,
                                    'B' => 3.0,
                                    'B-' => 2.7,
                                    'C+' => 2.3,
                                    'C' => 2.0,
                                    'C-' => 1.7,
                                    'D+' => 1.3,
                                    'D' => 1.0,
                                    'F' => 0.0
                                ];

                                $grade_point = $grade_points[$result['grade']];
                                $total_credits += $result['credit_hours'];
                                $total_grade_points += ($grade_point * $result['credit_hours']);
                            ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($result['course_code']); ?></td>
                                    <td><?php echo htmlspecialchars($result['course_name']); ?></td>
                                    <td><?php echo htmlspecialchars($result['credit_hours']); ?></td>
                                    <td><?php echo htmlspecialchars($result['grade']); ?></td>
                                    <td><?php echo number_format($grade_point, 2); ?></td>
                                </tr>
                            <?php
                            }
                            ?>
                        </tbody>
                    </table>
                </div>

                <!-- GPA Calculation -->
                <div class="gpa-section">
                    <h3>Grade Point Average (GPA)</h3>
                    <div class="gpa-info">
                        <p>Total Credits: <?php echo $total_credits; ?></p>
                        <p>GPA: <?php echo number_format($total_grade_points / $total_credits, 2); ?></p>
                    </div>
                </div>


                <!-- Replace the existing download button with this -->
                <div class="actions">
                    <button onclick="downloadResults()" class="download-btn">
                        <i class="fas fa-download"></i> Download Results
                    </button>
                </div>

                <?php echo $selected_semester ? '?semester=' . $selected_semester : ''; ?>"
            <?php
            } else {
                echo "<div class='no-results'>No results found for the selected semester.</div>";
            }
            ?>
        </div>
    </div>


    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Function to handle table sorting
            function makeTableSortable() {
                const table = document.querySelector('table');
                const headers = table.querySelectorAll('th');
                const tableBody = table.querySelector('tbody');
                const rows = Array.from(tableBody.querySelectorAll('tr'));

                headers.forEach((header, index) => {
                    header.addEventListener('click', () => {
                        const direction = header.classList.contains('asc') ? -1 : 1;
                        const sortedRows = rows.sort((a, b) => {
                            const aColText = a.querySelector(`td:nth-child(${index + 1})`).textContent.trim();
                            const bColText = b.querySelector(`td:nth-child(${index + 1})`).textContent.trim();

                            return aColText > bColText ? direction : -direction;
                        });

                        // Reset all headers
                        headers.forEach(h => h.classList.remove('asc', 'desc'));

                        // Add sort indicator
                        header.classList.toggle('asc', direction === 1);
                        header.classList.toggle('desc', direction === -1);

                        // Clear table body
                        while (tableBody.firstChild) {
                            tableBody.removeChild(tableBody.firstChild);
                        }

                        // Add sorted rows
                        sortedRows.forEach(row => tableBody.appendChild(row));
                    });
                });
            }

            // Function to handle semester selection
            function handleSemesterChange() {
                const select = document.querySelector('select[name="semester"]');
                select.addEventListener('change', function() {
                    // Show loading state
                    document.querySelector('.results-section').style.opacity = '0.5';
                    this.form.submit();
                });
            }

            // Function to print results
            function setupPrintButton() {
                const printBtn = document.createElement('button');
                printBtn.innerHTML = '<i class="fas fa-print"></i> Print Results';
                printBtn.className = 'download-btn print-btn';
                printBtn.style.marginLeft = '1rem';

                printBtn.addEventListener('click', function() {
                    window.print();
                });

                // Add print button next to download button
                document.querySelector('.actions').appendChild(printBtn);
            }

            // Function to hide nav when printing
            function setupPrintStyles() {
                const style = document.createElement('style');
                style.innerHTML = `
            @media print {
                .navbar, .semester-selection, .actions { display: none; }
                .results-section { box-shadow: none; }
                body { background: white; }
                @page { margin: 2cm; }
            }
        `;
                document.head.appendChild(style);
            }

            // Function to show loading state during page transitions
            function setupLoadingStates() {
                const links = document.querySelectorAll('a');
                links.forEach(link => {
                    link.addEventListener('click', () => {
                        if (!link.classList.contains('download-btn')) {
                            document.body.style.opacity = '0.5';
                        }
                    });
                });
            }

            function downloadResults() {
                // Select the container you want to export as a PDF
                const element = document.querySelector('.results-section');

                // Configure html2pdf.js options
                const options = {
                    margin: 0.5, // Margins in inches
                    filename: 'results.pdf', // Name of the generated PDF
                    image: {
                        type: 'jpeg',
                        quality: 0.98
                    }, // Image quality settings
                    html2canvas: {
                        scale: 2
                    }, // Use a higher scale for better quality
                    jsPDF: {
                        unit: 'in',
                        format: 'letter',
                        orientation: 'portrait'
                    } // PDF settings
                };

                // Generate and download the PDF
                html2pdf().set(options).from(element).save();
            }


            // Attach downloadResults to the download button
            const downloadBtn = document.querySelector('.download-btn');
            if (downloadBtn) {
                downloadBtn.addEventListener('click', downloadResults);
            }

            // Initialize all features
            makeTableSortable();
            handleSemesterChange();
            setupPrintButton();
            setupPrintStyles();
            setupLoadingStates();
        });
    </script>
</body>

</html>