<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
?>

<?php
// Define server details needed to connect to the database
$servername = 'localhost'; // The server where the database is hosted
$username = 'shadrack.berdah';        // The username to access the database
$password = '$@ddo174';            // The password to access the database (empty if none is set)
$dbname = 'webtech_fall2024_shadrack_berdah';      // The name of the database to connect to /srms_db

// Attempt to connect to the database using the provided details
$conn = mysqli_connect($servername, $username, $password, $dbname) 
    or die('Unable to connect'); // If the connection fails, display an error message and stop execution

// Check if the connection has an error and handle it
if ($conn->connect_error) {
    die('Connection failed'); // If there’s an error, stop execution and show 'Connection failed'
} else {
    // Connection was successful, so no further action is needed
}
?>